# Mathlib 4.30 Replayable-Subset Proof-Action Matrix

- Verdict: `no_nonempty_positive`
- Replay filter: `/workspace/thymic_project/paper/iclr_2/outputs/mathlib430_pretheorem_original_tactic_probe_fold0_500.json`
- Pool mode: `legacy`
- Candidate source: `retrieved_only`
- Replayable goals evaluated: 1
- Attempts: 10
- Verified attempts: 0
- Non-empty-premise verified attempts: 0
- Goals with any proof: 0
- Goals with non-empty-premise proof: 0
- Action-dependent goals: 0

## Status Counts

| Status | Count |
|---|---:|
| `lean_error` | 2 |
| `search_fail` | 1 |
| `simp_fail` | 7 |

## By Action

| Action | Verified | Non-empty verified | Attempts |
|---|---:|---:|---:|
| `aesop_core` | 0 | 0 | 1 |
| `aesop_core_plus_learned` | 0 | 0 | 1 |
| `aesop_core_plus_learned16` | 0 | 0 | 1 |
| `aesop_core_plus_learned32` | 0 | 0 | 1 |
| `aesop_core_plus_learned_swapped` | 0 | 0 | 1 |
| `aesop_learned16` | 0 | 0 | 1 |
| `aesop_learned32` | 0 | 0 | 1 |
| `aesop_learned8` | 0 | 0 | 1 |
| `hammerCore_core_plus_learned` | 0 | 0 | 1 |
| `hammer_empty` | 0 | 0 | 1 |

## By Goal

| Goal | Verified | Non-empty verified | Empty verified | Best |
|---|---:|---:|---:|---|
| `mathlib4::CategoryTheory.IsCardinalLocallyPresentable.iff_exists_isStrongGenerator` | 0 | 0 | 0 | none |

## Availability

| Goal | Checked | Available | Failed | Target/alias | Aesop-safe available | Aesop-unsafe available | Simp-safe available | Simp-unsafe available |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| `mathlib4::CategoryTheory.IsCardinalLocallyPresentable.iff_exists_isStrongGenerator` | 32 | 12 | 20 | 0 | 5 | 7 | 2 | 10 |

## Candidate Audit Summary

| Metric | Count |
|---|---:|
| `aesop_safe_fact_available` | 5 |
| `aesop_unsafe_fact_available` | 7 |
| `available` | 12 |
| `learned_candidate` | 32 |
| `proof_core` | 5 |
| `selected` | 32 |
| `simp_safe_available` | 2 |
| `simp_unsafe_available` | 10 |
| `target_or_alias` | 0 |
| `unavailable` | 20 |

### By Category

| Category | Count |
|---|---:|
| `theorem_like` | 16 |
| `class` | 7 |
| `definition_like` | 6 |
| `simp_attr` | 1 |
| `structure` | 1 |
| `unknown` | 1 |

### By Decl Kind

| Decl kind | Count |
|---|---:|
| `lemma` | 14 |
| `class` | 7 |
| `def` | 4 |
| `theorem` | 3 |
| `abbrev` | 2 |
| `structure` | 1 |
| `unknown` | 1 |

## Readout

- No non-empty-premise proof was found; inspect action failures before scaling.

# Mathlib 4.30 Replayable-Subset Proof-Action Matrix

- Verdict: `pass_action_dependent`
- Replay filter: `/workspace/thymic_project/paper/iclr_2/outputs/mathlib430_pretheorem_original_tactic_probe_fold0_500.json`
- Pool mode: `legacy`
- Candidate source: `retrieved_only`
- Replayable goals evaluated: 1
- Attempts: 10
- Verified attempts: 1
- Non-empty-premise verified attempts: 1
- Goals with any proof: 1
- Goals with non-empty-premise proof: 1
- Action-dependent goals: 1

## Status Counts

| Status | Count |
|---|---:|
| `lean_error` | 6 |
| `proved` | 1 |
| `search_fail` | 3 |

## By Action

| Action | Verified | Non-empty verified | Attempts |
|---|---:|---:|---:|
| `aesop_core` | 0 | 0 | 1 |
| `aesop_core_plus_learned` | 0 | 0 | 1 |
| `aesop_core_plus_learned16` | 0 | 0 | 1 |
| `aesop_core_plus_learned32` | 0 | 0 | 1 |
| `aesop_core_plus_learned_swapped` | 1 | 1 | 1 |
| `aesop_learned16` | 0 | 0 | 1 |
| `aesop_learned32` | 0 | 0 | 1 |
| `aesop_learned8` | 0 | 0 | 1 |
| `hammerCore_core_plus_learned` | 0 | 0 | 1 |
| `hammer_empty` | 0 | 0 | 1 |

## By Goal

| Goal | Verified | Non-empty verified | Empty verified | Best |
|---|---:|---:|---:|---|
| `mathlib4::Polynomial.hilbertPoly_X_pow_succ` | 1 | 1 | 0 | `aesop_core_plus_learned_swapped` (4 facts, 8 simps) |

## Availability

| Goal | Checked | Available | Failed | Target/alias | Aesop-safe available | Aesop-unsafe available | Simp-safe available | Simp-unsafe available |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| `mathlib4::Polynomial.hilbertPoly_X_pow_succ` | 32 | 19 | 13 | 0 | 16 | 3 | 2 | 17 |

## Candidate Audit Summary

| Metric | Count |
|---|---:|
| `aesop_safe_fact_available` | 16 |
| `aesop_unsafe_fact_available` | 3 |
| `available` | 19 |
| `learned_candidate` | 32 |
| `proof_core` | 3 |
| `selected` | 32 |
| `simp_safe_available` | 2 |
| `simp_unsafe_available` | 17 |
| `target_or_alias` | 0 |
| `unavailable` | 13 |

### By Category

| Category | Count |
|---|---:|
| `theorem_like` | 21 |
| `definition_like` | 7 |
| `simp_attr` | 4 |

### By Decl Kind

| Decl kind | Count |
|---|---:|
| `theorem` | 18 |
| `def` | 7 |
| `lemma` | 7 |

## Readout

- This pilot found at least one action-dependent proof, so the proof-action routing route should be scaled.

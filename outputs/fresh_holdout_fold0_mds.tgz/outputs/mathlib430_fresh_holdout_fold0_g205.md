# Mathlib 4.30 Replayable-Subset Proof-Action Matrix

- Verdict: `no_nonempty_positive`
- Replay filter: `/workspace/thymic_project/paper/iclr_2/outputs/mathlib430_pretheorem_original_tactic_probe_fold0_500.json`
- Pool mode: `legacy`
- Candidate source: `retrieved_only`
- Replayable goals evaluated: 1
- Attempts: 10
- Verified attempts: 0
- Non-empty-premise verified attempts: 0
- Goals with any proof: 0
- Goals with non-empty-premise proof: 0
- Action-dependent goals: 0

## Status Counts

| Status | Count |
|---|---:|
| `search_fail` | 10 |

## By Action

| Action | Verified | Non-empty verified | Attempts |
|---|---:|---:|---:|
| `aesop_core` | 0 | 0 | 1 |
| `aesop_core_plus_learned` | 0 | 0 | 1 |
| `aesop_core_plus_learned16` | 0 | 0 | 1 |
| `aesop_core_plus_learned32` | 0 | 0 | 1 |
| `aesop_core_plus_learned_swapped` | 0 | 0 | 1 |
| `aesop_learned16` | 0 | 0 | 1 |
| `aesop_learned32` | 0 | 0 | 1 |
| `aesop_learned8` | 0 | 0 | 1 |
| `hammerCore_core_plus_learned` | 0 | 0 | 1 |
| `hammer_empty` | 0 | 0 | 1 |

## By Goal

| Goal | Verified | Non-empty verified | Empty verified | Best |
|---|---:|---:|---:|---|
| `mathlib4::CategoryTheory.ComonObj.Comon.ComonObj.counit_comul_hom` | 0 | 0 | 0 | none |

## Availability

| Goal | Checked | Available | Failed | Target/alias | Aesop-safe available | Aesop-unsafe available | Simp-safe available | Simp-unsafe available |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| `mathlib4::CategoryTheory.ComonObj.Comon.ComonObj.counit_comul_hom` | 32 | 9 | 23 | 0 | 5 | 4 | 4 | 5 |

## Candidate Audit Summary

| Metric | Count |
|---|---:|
| `aesop_safe_fact_available` | 5 |
| `aesop_unsafe_fact_available` | 4 |
| `available` | 9 |
| `learned_candidate` | 32 |
| `proof_core` | 1 |
| `selected` | 32 |
| `simp_safe_available` | 4 |
| `simp_unsafe_available` | 5 |
| `target_or_alias` | 0 |
| `unavailable` | 23 |

### By Category

| Category | Count |
|---|---:|
| `simp_attr` | 17 |
| `definition_like` | 5 |
| `class` | 4 |
| `theorem_like` | 4 |
| `structure` | 2 |

### By Decl Kind

| Decl kind | Count |
|---|---:|
| `def` | 13 |
| `theorem` | 8 |
| `class` | 4 |
| `lemma` | 4 |
| `structure` | 2 |
| `unknown` | 1 |

## Readout

- No non-empty-premise proof was found; inspect action failures before scaling.

# Mathlib 4.30 Replayable-Subset Proof-Action Matrix

- Verdict: `no_nonempty_positive`
- Replay filter: `/workspace/thymic_project/paper/iclr_2/outputs/mathlib430_pretheorem_original_tactic_probe_fold0_500.json`
- Pool mode: `legacy`
- Candidate source: `retrieved_only`
- Replayable goals evaluated: 1
- Attempts: 10
- Verified attempts: 0
- Non-empty-premise verified attempts: 0
- Goals with any proof: 0
- Goals with non-empty-premise proof: 0
- Action-dependent goals: 0

## Status Counts

| Status | Count |
|---|---:|
| `lean_error` | 1 |
| `search_fail` | 1 |
| `simp_fail` | 1 |
| `timeout` | 7 |

## By Action

| Action | Verified | Non-empty verified | Attempts |
|---|---:|---:|---:|
| `aesop_core` | 0 | 0 | 1 |
| `aesop_core_plus_learned` | 0 | 0 | 1 |
| `aesop_core_plus_learned16` | 0 | 0 | 1 |
| `aesop_core_plus_learned32` | 0 | 0 | 1 |
| `aesop_core_plus_learned_swapped` | 0 | 0 | 1 |
| `aesop_learned16` | 0 | 0 | 1 |
| `aesop_learned32` | 0 | 0 | 1 |
| `aesop_learned8` | 0 | 0 | 1 |
| `hammerCore_core_plus_learned` | 0 | 0 | 1 |
| `hammer_empty` | 0 | 0 | 1 |

## By Goal

| Goal | Verified | Non-empty verified | Empty verified | Best |
|---|---:|---:|---:|---|
| `mathlib4::Finset.ENNReal.NNReal.summable_schlomilch_iff` | 0 | 0 | 0 | none |

## Availability

| Goal | Checked | Available | Failed | Target/alias | Aesop-safe available | Aesop-unsafe available | Simp-safe available | Simp-unsafe available |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| `mathlib4::Finset.ENNReal.NNReal.summable_schlomilch_iff` | 32 | 28 | 4 | 0 | 25 | 3 | 4 | 24 |

## Candidate Audit Summary

| Metric | Count |
|---|---:|
| `aesop_safe_fact_available` | 25 |
| `aesop_unsafe_fact_available` | 3 |
| `available` | 28 |
| `learned_candidate` | 32 |
| `proof_core` | 9 |
| `selected` | 32 |
| `simp_safe_available` | 4 |
| `simp_unsafe_available` | 24 |
| `target_or_alias` | 0 |
| `unavailable` | 4 |

### By Category

| Category | Count |
|---|---:|
| `theorem_like` | 26 |
| `definition_like` | 3 |
| `simp_attr` | 3 |

### By Decl Kind

| Decl kind | Count |
|---|---:|
| `theorem` | 21 |
| `lemma` | 8 |
| `def` | 3 |

## Readout

- No non-empty-premise proof was found; inspect action failures before scaling.

# Mathlib 4.30 Replayable-Subset Proof-Action Matrix

- Verdict: `pass_action_dependent`
- Replay filter: `/workspace/thymic_project/paper/iclr_2/outputs/mathlib430_pretheorem_original_tactic_probe_fold0_500.json`
- Pool mode: `legacy`
- Candidate source: `retrieved_only`
- Replayable goals evaluated: 1
- Attempts: 10
- Verified attempts: 7
- Non-empty-premise verified attempts: 7
- Goals with any proof: 1
- Goals with non-empty-premise proof: 1
- Action-dependent goals: 1

## Status Counts

| Status | Count |
|---|---:|
| `lean_error` | 1 |
| `proved` | 7 |
| `search_fail` | 2 |

## By Action

| Action | Verified | Non-empty verified | Attempts |
|---|---:|---:|---:|
| `aesop_core` | 0 | 0 | 1 |
| `aesop_core_plus_learned` | 1 | 1 | 1 |
| `aesop_core_plus_learned16` | 1 | 1 | 1 |
| `aesop_core_plus_learned32` | 1 | 1 | 1 |
| `aesop_core_plus_learned_swapped` | 1 | 1 | 1 |
| `aesop_learned16` | 1 | 1 | 1 |
| `aesop_learned32` | 1 | 1 | 1 |
| `aesop_learned8` | 1 | 1 | 1 |
| `hammerCore_core_plus_learned` | 0 | 0 | 1 |
| `hammer_empty` | 0 | 0 | 1 |

## By Goal

| Goal | Verified | Non-empty verified | Empty verified | Best |
|---|---:|---:|---:|---|
| `mathlib4::CochainComplex.IsKInjective.rightOrthogonal` | 7 | 7 | 0 | `aesop_core_plus_learned` (8 facts, 4 simps) |

## Availability

| Goal | Checked | Available | Failed | Target/alias | Aesop-safe available | Aesop-unsafe available | Simp-safe available | Simp-unsafe available |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| `mathlib4::CochainComplex.IsKInjective.rightOrthogonal` | 32 | 13 | 19 | 1 | 8 | 5 | 0 | 13 |

## Candidate Audit Summary

| Metric | Count |
|---|---:|
| `aesop_safe_fact_available` | 8 |
| `aesop_unsafe_fact_available` | 5 |
| `available` | 13 |
| `learned_candidate` | 32 |
| `proof_core` | 4 |
| `selected` | 32 |
| `simp_safe_available` | 0 |
| `simp_unsafe_available` | 13 |
| `target_or_alias` | 1 |
| `unavailable` | 19 |

### By Category

| Category | Count |
|---|---:|
| `definition_like` | 18 |
| `theorem_like` | 10 |
| `unknown` | 2 |
| `class` | 1 |
| `simp_attr` | 1 |

### By Decl Kind

| Decl kind | Count |
|---|---:|
| `def` | 14 |
| `lemma` | 9 |
| `abbrev` | 5 |
| `unknown` | 2 |
| `class` | 1 |
| `theorem` | 1 |

## Readout

- This pilot found at least one action-dependent proof, so the proof-action routing route should be scaled.

# Mathlib 4.30 Replayable-Subset Proof-Action Matrix

- Verdict: `no_nonempty_positive`
- Replay filter: `/workspace/thymic_project/paper/iclr_2/outputs/mathlib430_pretheorem_original_tactic_probe_fold0_500.json`
- Pool mode: `legacy`
- Candidate source: `retrieved_only`
- Replayable goals evaluated: 1
- Attempts: 10
- Verified attempts: 0
- Non-empty-premise verified attempts: 0
- Goals with any proof: 0
- Goals with non-empty-premise proof: 0
- Action-dependent goals: 0

## Status Counts

| Status | Count |
|---|---:|
| `search_fail` | 3 |
| `simp_fail` | 6 |
| `timeout` | 1 |

## By Action

| Action | Verified | Non-empty verified | Attempts |
|---|---:|---:|---:|
| `aesop_core` | 0 | 0 | 1 |
| `aesop_core_plus_learned` | 0 | 0 | 1 |
| `aesop_core_plus_learned16` | 0 | 0 | 1 |
| `aesop_core_plus_learned32` | 0 | 0 | 1 |
| `aesop_core_plus_learned_swapped` | 0 | 0 | 1 |
| `aesop_learned16` | 0 | 0 | 1 |
| `aesop_learned32` | 0 | 0 | 1 |
| `aesop_learned8` | 0 | 0 | 1 |
| `hammerCore_core_plus_learned` | 0 | 0 | 1 |
| `hammer_empty` | 0 | 0 | 1 |

## By Goal

| Goal | Verified | Non-empty verified | Empty verified | Best |
|---|---:|---:|---:|---|
| `mathlib4::Module.Flat.Flat.Algebra.TensorProduct.Submodule.TensorProduct.map_injective_of_flat_flat'` | 0 | 0 | 0 | none |

## Availability

| Goal | Checked | Available | Failed | Target/alias | Aesop-safe available | Aesop-unsafe available | Simp-safe available | Simp-unsafe available |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| `mathlib4::Module.Flat.Flat.Algebra.TensorProduct.Submodule.TensorProduct.map_injective_of_flat_flat'` | 32 | 25 | 7 | 0 | 13 | 12 | 2 | 23 |

## Candidate Audit Summary

| Metric | Count |
|---|---:|
| `aesop_safe_fact_available` | 13 |
| `aesop_unsafe_fact_available` | 12 |
| `available` | 25 |
| `learned_candidate` | 32 |
| `proof_core` | 4 |
| `selected` | 32 |
| `simp_safe_available` | 2 |
| `simp_unsafe_available` | 23 |
| `target_or_alias` | 0 |
| `unavailable` | 7 |

### By Category

| Category | Count |
|---|---:|
| `theorem_like` | 16 |
| `definition_like` | 8 |
| `instance` | 5 |
| `simp_attr` | 2 |
| `class` | 1 |

### By Decl Kind

| Decl kind | Count |
|---|---:|
| `lemma` | 9 |
| `theorem` | 9 |
| `def` | 8 |
| `instance` | 5 |
| `class` | 1 |

## Readout

- No non-empty-premise proof was found; inspect action failures before scaling.

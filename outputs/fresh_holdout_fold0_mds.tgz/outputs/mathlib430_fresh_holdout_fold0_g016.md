# Mathlib 4.30 Replayable-Subset Proof-Action Matrix

- Verdict: `no_nonempty_positive`
- Replay filter: `/workspace/thymic_project/paper/iclr_2/outputs/mathlib430_pretheorem_original_tactic_probe_fold0_500.json`
- Pool mode: `legacy`
- Candidate source: `retrieved_only`
- Replayable goals evaluated: 1
- Attempts: 10
- Verified attempts: 0
- Non-empty-premise verified attempts: 0
- Goals with any proof: 0
- Goals with non-empty-premise proof: 0
- Action-dependent goals: 0

## Status Counts

| Status | Count |
|---|---:|
| `lean_error` | 7 |
| `search_fail` | 3 |

## By Action

| Action | Verified | Non-empty verified | Attempts |
|---|---:|---:|---:|
| `aesop_core` | 0 | 0 | 1 |
| `aesop_core_plus_learned` | 0 | 0 | 1 |
| `aesop_core_plus_learned16` | 0 | 0 | 1 |
| `aesop_core_plus_learned32` | 0 | 0 | 1 |
| `aesop_core_plus_learned_swapped` | 0 | 0 | 1 |
| `aesop_learned16` | 0 | 0 | 1 |
| `aesop_learned32` | 0 | 0 | 1 |
| `aesop_learned8` | 0 | 0 | 1 |
| `hammerCore_core_plus_learned` | 0 | 0 | 1 |
| `hammer_empty` | 0 | 0 | 1 |

## By Goal

| Goal | Verified | Non-empty verified | Empty verified | Best |
|---|---:|---:|---:|---|
| `mathlib4::PowerSeries.monomial_eq_C_mul_X_pow` | 0 | 0 | 0 | none |

## Availability

| Goal | Checked | Available | Failed | Target/alias | Aesop-safe available | Aesop-unsafe available | Simp-safe available | Simp-unsafe available |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| `mathlib4::PowerSeries.monomial_eq_C_mul_X_pow` | 32 | 22 | 10 | 0 | 17 | 5 | 7 | 15 |

## Candidate Audit Summary

| Metric | Count |
|---|---:|
| `aesop_safe_fact_available` | 17 |
| `aesop_unsafe_fact_available` | 5 |
| `available` | 22 |
| `learned_candidate` | 32 |
| `proof_core` | 5 |
| `selected` | 32 |
| `simp_safe_available` | 7 |
| `simp_unsafe_available` | 15 |
| `target_or_alias` | 0 |
| `unavailable` | 10 |

### By Category

| Category | Count |
|---|---:|
| `theorem_like` | 16 |
| `definition_like` | 8 |
| `simp_attr` | 8 |

### By Decl Kind

| Decl kind | Count |
|---|---:|
| `theorem` | 20 |
| `def` | 8 |
| `lemma` | 4 |

## Readout

- No non-empty-premise proof was found; inspect action failures before scaling.

# Mathlib 4.30 Replayable-Subset Proof-Action Matrix

- Verdict: `pass_action_dependent`
- Replay filter: `/workspace/thymic_project/paper/iclr_2/outputs/mathlib430_pretheorem_original_tactic_probe_fold0_500.json`
- Pool mode: `legacy`
- Candidate source: `retrieved_only`
- Replayable goals evaluated: 1
- Attempts: 10
- Verified attempts: 1
- Non-empty-premise verified attempts: 1
- Goals with any proof: 1
- Goals with non-empty-premise proof: 1
- Action-dependent goals: 1

## Status Counts

| Status | Count |
|---|---:|
| `lean_error` | 6 |
| `proved` | 1 |
| `search_fail` | 3 |

## By Action

| Action | Verified | Non-empty verified | Attempts |
|---|---:|---:|---:|
| `aesop_core` | 0 | 0 | 1 |
| `aesop_core_plus_learned` | 0 | 0 | 1 |
| `aesop_core_plus_learned16` | 0 | 0 | 1 |
| `aesop_core_plus_learned32` | 0 | 0 | 1 |
| `aesop_core_plus_learned_swapped` | 1 | 1 | 1 |
| `aesop_learned16` | 0 | 0 | 1 |
| `aesop_learned32` | 0 | 0 | 1 |
| `aesop_learned8` | 0 | 0 | 1 |
| `hammerCore_core_plus_learned` | 0 | 0 | 1 |
| `hammer_empty` | 0 | 0 | 1 |

## By Goal

| Goal | Verified | Non-empty verified | Empty verified | Best |
|---|---:|---:|---:|---|
| `mathlib4::WithLp.prod_norm_eq_idemFst_sup_idemSnd` | 1 | 1 | 0 | `aesop_core_plus_learned_swapped` (8 facts, 8 simps) |

## Availability

| Goal | Checked | Available | Failed | Target/alias | Aesop-safe available | Aesop-unsafe available | Simp-safe available | Simp-unsafe available |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| `mathlib4::WithLp.prod_norm_eq_idemFst_sup_idemSnd` | 32 | 24 | 8 | 0 | 17 | 7 | 11 | 13 |

## Candidate Audit Summary

| Metric | Count |
|---|---:|
| `aesop_safe_fact_available` | 17 |
| `aesop_unsafe_fact_available` | 7 |
| `available` | 24 |
| `learned_candidate` | 32 |
| `proof_core` | 4 |
| `selected` | 32 |
| `simp_safe_available` | 11 |
| `simp_unsafe_available` | 13 |
| `target_or_alias` | 0 |
| `unavailable` | 8 |

### By Category

| Category | Count |
|---|---:|
| `theorem_like` | 13 |
| `simp_attr` | 10 |
| `definition_like` | 8 |
| `structure` | 1 |

### By Decl Kind

| Decl kind | Count |
|---|---:|
| `lemma` | 14 |
| `def` | 8 |
| `theorem` | 6 |
| `abbrev` | 3 |
| `structure` | 1 |

## Readout

- This pilot found at least one action-dependent proof, so the proof-action routing route should be scaled.

# Mathlib 4.30 Replayable-Subset Proof-Action Matrix

- Verdict: `partial_nonempty_positive`
- Replay filter: `/workspace/thymic_project/paper/iclr_2/outputs/mathlib430_pretheorem_original_tactic_probe_fold0_500.json`
- Pool mode: `legacy`
- Candidate source: `retrieved_only`
- Replayable goals evaluated: 1
- Attempts: 10
- Verified attempts: 9
- Non-empty-premise verified attempts: 7
- Goals with any proof: 1
- Goals with non-empty-premise proof: 1
- Action-dependent goals: 0

## Status Counts

| Status | Count |
|---|---:|
| `proved` | 9 |
| `search_fail` | 1 |

## By Action

| Action | Verified | Non-empty verified | Attempts |
|---|---:|---:|---:|
| `aesop_core` | 1 | 0 | 1 |
| `aesop_core_plus_learned` | 1 | 1 | 1 |
| `aesop_core_plus_learned16` | 1 | 1 | 1 |
| `aesop_core_plus_learned32` | 1 | 1 | 1 |
| `aesop_core_plus_learned_swapped` | 1 | 1 | 1 |
| `aesop_learned16` | 1 | 1 | 1 |
| `aesop_learned32` | 1 | 1 | 1 |
| `aesop_learned8` | 1 | 1 | 1 |
| `hammerCore_core_plus_learned` | 0 | 0 | 1 |
| `hammer_empty` | 1 | 0 | 1 |

## By Goal

| Goal | Verified | Non-empty verified | Empty verified | Best |
|---|---:|---:|---:|---|
| `mathlib4::QuadraticMap.associated_prod` | 9 | 7 | 2 | `hammer_empty` (0 facts, 0 simps) |

## Availability

| Goal | Checked | Available | Failed | Target/alias | Aesop-safe available | Aesop-unsafe available | Simp-safe available | Simp-unsafe available |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| `mathlib4::QuadraticMap.associated_prod` | 32 | 15 | 17 | 0 | 7 | 8 | 8 | 7 |

## Candidate Audit Summary

| Metric | Count |
|---|---:|
| `aesop_safe_fact_available` | 7 |
| `aesop_unsafe_fact_available` | 8 |
| `available` | 15 |
| `learned_candidate` | 32 |
| `proof_core` | 3 |
| `selected` | 32 |
| `simp_safe_available` | 8 |
| `simp_unsafe_available` | 7 |
| `target_or_alias` | 0 |
| `unavailable` | 17 |

### By Category

| Category | Count |
|---|---:|
| `simp_attr` | 15 |
| `theorem_like` | 11 |
| `definition_like` | 5 |
| `class` | 1 |

### By Decl Kind

| Decl kind | Count |
|---|---:|
| `def` | 14 |
| `theorem` | 13 |
| `lemma` | 4 |
| `class` | 1 |

## Readout

- Non-empty-premise proofs exist, but empty baselines also solve those goals; scale cautiously and separate easy goals.

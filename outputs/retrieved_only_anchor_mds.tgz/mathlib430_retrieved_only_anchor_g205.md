# Mathlib 4.30 Replayable-Subset Proof-Action Matrix

- Verdict: `partial_nonempty_positive`
- Replay filter: `/workspace/thymic_project/paper/iclr_2/outputs/mathlib430_pretheorem_original_tactic_probe_490.json`
- Pool mode: `legacy`
- Candidate source: `retrieved_only`
- Replayable goals evaluated: 1
- Attempts: 74
- Verified attempts: 54
- Non-empty-premise verified attempts: 46
- Goals with any proof: 1
- Goals with non-empty-premise proof: 1
- Action-dependent goals: 0

## Status Counts

| Status | Count |
|---|---:|
| `lean_error` | 5 |
| `proved` | 54 |
| `rewrite_fail` | 4 |
| `search_fail` | 4 |
| `simp_fail` | 2 |
| `skipped_empty_action` | 5 |

## By Action

| Action | Verified | Non-empty verified | Attempts |
|---|---:|---:|---:|
| `aesop_core` | 1 | 0 | 1 |
| `aesop_core_facts` | 1 | 0 | 1 |
| `aesop_core_plus_learned` | 1 | 1 | 1 |
| `aesop_core_plus_learned16` | 1 | 1 | 1 |
| `aesop_core_plus_learned16_facts` | 1 | 1 | 1 |
| `aesop_core_plus_learned16_simps` | 1 | 1 | 1 |
| `aesop_core_plus_learned32` | 1 | 1 | 1 |
| `aesop_core_plus_learned32_facts` | 1 | 1 | 1 |
| `aesop_core_plus_learned32_simps` | 1 | 1 | 1 |
| `aesop_core_plus_learned_countmatched_facts` | 1 | 1 | 1 |
| `aesop_core_plus_learned_countmatched_simps` | 1 | 1 | 1 |
| `aesop_core_plus_learned_facts` | 1 | 1 | 1 |
| `aesop_core_plus_learned_identity` | 1 | 1 | 1 |
| `aesop_core_plus_learned_random_split` | 1 | 1 | 1 |
| `aesop_core_plus_learned_simps` | 1 | 1 | 1 |
| `aesop_core_plus_learned_swapped` | 1 | 1 | 1 |
| `aesop_core_simps` | 1 | 0 | 1 |
| `aesop_empty` | 1 | 0 | 1 |
| `aesop_learned16` | 1 | 1 | 1 |
| `aesop_learned16_facts` | 1 | 1 | 1 |
| `aesop_learned16_simps` | 1 | 1 | 1 |
| `aesop_learned32` | 1 | 1 | 1 |
| `aesop_learned32_facts` | 1 | 1 | 1 |
| `aesop_learned32_simps` | 1 | 1 | 1 |
| `aesop_learned8` | 1 | 1 | 1 |
| `aesop_learned8_countmatched_facts` | 1 | 1 | 1 |
| `aesop_learned8_countmatched_simps` | 1 | 1 | 1 |
| `aesop_learned8_facts` | 1 | 1 | 1 |
| `aesop_learned8_identity` | 1 | 1 | 1 |
| `aesop_learned8_random_split` | 1 | 1 | 1 |
| `aesop_learned8_simps` | 1 | 1 | 1 |
| `aesop_learned8_swapped` | 1 | 1 | 1 |
| `hammerCore_core` | 1 | 0 | 1 |
| `hammerCore_core_plus_learned` | 1 | 1 | 1 |
| `hammerCore_core_plus_learned16` | 1 | 1 | 1 |
| `hammerCore_core_plus_learned32` | 1 | 1 | 1 |
| `hammer_core_facts` | 1 | 0 | 1 |
| `hammer_core_plus_learned` | 1 | 1 | 1 |
| `hammer_core_plus_learned16` | 1 | 1 | 1 |
| `hammer_core_plus_learned32` | 1 | 1 | 1 |
| `hammer_empty` | 1 | 0 | 1 |
| `linarith_empty` | 0 | 0 | 1 |
| `nlinarith_empty` | 0 | 0 | 1 |
| `norm_num_empty` | 0 | 0 | 1 |
| `omega_empty` | 0 | 0 | 1 |
| `ring_nf_empty` | 0 | 0 | 1 |
| `rw_core` | 0 | 0 | 1 |
| `rw_core_plus_learned` | 0 | 0 | 1 |
| `rw_core_plus_learned_then_simp` | 0 | 0 | 1 |
| `rw_core_then_simp` | 0 | 0 | 1 |
| `simp_all_core` | 0 | 0 | 1 |
| `simp_all_core_plus_learned` | 1 | 1 | 1 |
| `simp_all_core_plus_learned16` | 1 | 1 | 1 |
| `simp_all_core_plus_learned32` | 1 | 1 | 1 |
| `simp_core` | 0 | 0 | 1 |
| `simp_core_plus_learned` | 1 | 1 | 1 |
| `simp_core_plus_learned16` | 1 | 1 | 1 |
| `simp_core_plus_learned32` | 1 | 1 | 1 |
| `simp_empty` | 0 | 0 | 1 |
| `simp_only_core` | 0 | 0 | 1 |
| `simp_only_core_plus_learned` | 0 | 0 | 1 |
| `simp_rw_core` | 0 | 0 | 1 |
| `simp_rw_core_plus_learned` | 0 | 0 | 1 |
| `simp_rw_core_plus_learned_then_simp` | 0 | 0 | 1 |
| `simp_rw_core_then_simp` | 0 | 0 | 1 |
| `simpa_core` | 0 | 0 | 1 |
| `simpa_core_plus_learned` | 1 | 1 | 1 |
| `simpa_core_plus_learned16` | 1 | 1 | 1 |
| `simpa_core_plus_learned32` | 1 | 1 | 1 |
| `simpa_empty` | 0 | 0 | 1 |
| `solve_by_elim_core` | 1 | 0 | 1 |
| `solve_by_elim_core_plus_learned` | 1 | 1 | 1 |
| `solve_by_elim_core_plus_learned16` | 1 | 1 | 1 |
| `solve_by_elim_core_plus_learned32` | 1 | 1 | 1 |

## By Goal

| Goal | Verified | Non-empty verified | Empty verified | Best |
|---|---:|---:|---:|---|
| `mathlib4::Finset.max'_singleton` | 54 | 46 | 8 | `hammer_empty` (0 facts, 0 simps) |

## Availability

| Goal | Checked | Available | Failed | Target/alias | Aesop-safe available | Aesop-unsafe available | Simp-safe available | Simp-unsafe available |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| `mathlib4::Finset.max'_singleton` | 32 | 20 | 12 | 0 | 15 | 5 | 8 | 12 |

## Candidate Audit Summary

| Metric | Count |
|---|---:|
| `aesop_safe_fact_available` | 15 |
| `aesop_unsafe_fact_available` | 5 |
| `available` | 20 |
| `learned_candidate` | 32 |
| `proof_core` | 2 |
| `selected` | 32 |
| `simp_safe_available` | 8 |
| `simp_unsafe_available` | 12 |
| `target_or_alias` | 0 |
| `unavailable` | 12 |

### By Category

| Category | Count |
|---|---:|
| `simp_attr` | 16 |
| `theorem_like` | 10 |
| `definition_like` | 5 |
| `structure` | 1 |

### By Decl Kind

| Decl kind | Count |
|---|---:|
| `theorem` | 20 |
| `lemma` | 6 |
| `def` | 5 |
| `structure` | 1 |

## Readout

- Non-empty-premise proofs exist, but empty baselines also solve those goals; scale cautiously and separate easy goals.

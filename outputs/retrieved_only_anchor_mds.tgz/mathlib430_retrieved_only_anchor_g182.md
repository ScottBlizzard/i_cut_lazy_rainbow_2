# Mathlib 4.30 Replayable-Subset Proof-Action Matrix

- Verdict: `no_nonempty_positive`
- Replay filter: `/workspace/thymic_project/paper/iclr_2/outputs/mathlib430_pretheorem_original_tactic_probe_490.json`
- Pool mode: `legacy`
- Candidate source: `retrieved_only`
- Replayable goals evaluated: 1
- Attempts: 74
- Verified attempts: 0
- Non-empty-premise verified attempts: 0
- Goals with any proof: 0
- Goals with non-empty-premise proof: 0
- Action-dependent goals: 0

## Status Counts

| Status | Count |
|---|---:|
| `lean_error` | 23 |
| `rewrite_fail` | 2 |
| `search_fail` | 15 |
| `simp_fail` | 24 |
| `skipped_empty_action` | 5 |
| `typeclass_or_inference` | 5 |

## By Action

| Action | Verified | Non-empty verified | Attempts |
|---|---:|---:|---:|
| `aesop_core` | 0 | 0 | 1 |
| `aesop_core_facts` | 0 | 0 | 1 |
| `aesop_core_plus_learned` | 0 | 0 | 1 |
| `aesop_core_plus_learned16` | 0 | 0 | 1 |
| `aesop_core_plus_learned16_facts` | 0 | 0 | 1 |
| `aesop_core_plus_learned16_simps` | 0 | 0 | 1 |
| `aesop_core_plus_learned32` | 0 | 0 | 1 |
| `aesop_core_plus_learned32_facts` | 0 | 0 | 1 |
| `aesop_core_plus_learned32_simps` | 0 | 0 | 1 |
| `aesop_core_plus_learned_countmatched_facts` | 0 | 0 | 1 |
| `aesop_core_plus_learned_countmatched_simps` | 0 | 0 | 1 |
| `aesop_core_plus_learned_facts` | 0 | 0 | 1 |
| `aesop_core_plus_learned_identity` | 0 | 0 | 1 |
| `aesop_core_plus_learned_random_split` | 0 | 0 | 1 |
| `aesop_core_plus_learned_simps` | 0 | 0 | 1 |
| `aesop_core_plus_learned_swapped` | 0 | 0 | 1 |
| `aesop_core_simps` | 0 | 0 | 1 |
| `aesop_empty` | 0 | 0 | 1 |
| `aesop_learned16` | 0 | 0 | 1 |
| `aesop_learned16_facts` | 0 | 0 | 1 |
| `aesop_learned16_simps` | 0 | 0 | 1 |
| `aesop_learned32` | 0 | 0 | 1 |
| `aesop_learned32_facts` | 0 | 0 | 1 |
| `aesop_learned32_simps` | 0 | 0 | 1 |
| `aesop_learned8` | 0 | 0 | 1 |
| `aesop_learned8_countmatched_facts` | 0 | 0 | 1 |
| `aesop_learned8_countmatched_simps` | 0 | 0 | 1 |
| `aesop_learned8_facts` | 0 | 0 | 1 |
| `aesop_learned8_identity` | 0 | 0 | 1 |
| `aesop_learned8_random_split` | 0 | 0 | 1 |
| `aesop_learned8_simps` | 0 | 0 | 1 |
| `aesop_learned8_swapped` | 0 | 0 | 1 |
| `hammerCore_core` | 0 | 0 | 1 |
| `hammerCore_core_plus_learned` | 0 | 0 | 1 |
| `hammerCore_core_plus_learned16` | 0 | 0 | 1 |
| `hammerCore_core_plus_learned32` | 0 | 0 | 1 |
| `hammer_core_facts` | 0 | 0 | 1 |
| `hammer_core_plus_learned` | 0 | 0 | 1 |
| `hammer_core_plus_learned16` | 0 | 0 | 1 |
| `hammer_core_plus_learned32` | 0 | 0 | 1 |
| `hammer_empty` | 0 | 0 | 1 |
| `linarith_empty` | 0 | 0 | 1 |
| `nlinarith_empty` | 0 | 0 | 1 |
| `norm_num_empty` | 0 | 0 | 1 |
| `omega_empty` | 0 | 0 | 1 |
| `ring_nf_empty` | 0 | 0 | 1 |
| `rw_core` | 0 | 0 | 1 |
| `rw_core_plus_learned` | 0 | 0 | 1 |
| `rw_core_plus_learned_then_simp` | 0 | 0 | 1 |
| `rw_core_then_simp` | 0 | 0 | 1 |
| `simp_all_core` | 0 | 0 | 1 |
| `simp_all_core_plus_learned` | 0 | 0 | 1 |
| `simp_all_core_plus_learned16` | 0 | 0 | 1 |
| `simp_all_core_plus_learned32` | 0 | 0 | 1 |
| `simp_core` | 0 | 0 | 1 |
| `simp_core_plus_learned` | 0 | 0 | 1 |
| `simp_core_plus_learned16` | 0 | 0 | 1 |
| `simp_core_plus_learned32` | 0 | 0 | 1 |
| `simp_empty` | 0 | 0 | 1 |
| `simp_only_core` | 0 | 0 | 1 |
| `simp_only_core_plus_learned` | 0 | 0 | 1 |
| `simp_rw_core` | 0 | 0 | 1 |
| `simp_rw_core_plus_learned` | 0 | 0 | 1 |
| `simp_rw_core_plus_learned_then_simp` | 0 | 0 | 1 |
| `simp_rw_core_then_simp` | 0 | 0 | 1 |
| `simpa_core` | 0 | 0 | 1 |
| `simpa_core_plus_learned` | 0 | 0 | 1 |
| `simpa_core_plus_learned16` | 0 | 0 | 1 |
| `simpa_core_plus_learned32` | 0 | 0 | 1 |
| `simpa_empty` | 0 | 0 | 1 |
| `solve_by_elim_core` | 0 | 0 | 1 |
| `solve_by_elim_core_plus_learned` | 0 | 0 | 1 |
| `solve_by_elim_core_plus_learned16` | 0 | 0 | 1 |
| `solve_by_elim_core_plus_learned32` | 0 | 0 | 1 |

## By Goal

| Goal | Verified | Non-empty verified | Empty verified | Best |
|---|---:|---:|---:|---|
| `mathlib4::Nat.Function.Involutive.Even.neg_one_zpow` | 0 | 0 | 0 | none |

## Availability

| Goal | Checked | Available | Failed | Target/alias | Aesop-safe available | Aesop-unsafe available | Simp-safe available | Simp-unsafe available |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| `mathlib4::Nat.Function.Involutive.Even.neg_one_zpow` | 32 | 30 | 2 | 0 | 30 | 0 | 19 | 11 |

## Candidate Audit Summary

| Metric | Count |
|---|---:|
| `aesop_safe_fact_available` | 30 |
| `aesop_unsafe_fact_available` | 0 |
| `available` | 30 |
| `learned_candidate` | 32 |
| `proof_core` | 0 |
| `selected` | 32 |
| `simp_safe_available` | 19 |
| `simp_unsafe_available` | 11 |
| `target_or_alias` | 0 |
| `unavailable` | 2 |

### By Category

| Category | Count |
|---|---:|
| `simp_attr` | 19 |
| `theorem_like` | 13 |

### By Decl Kind

| Decl kind | Count |
|---|---:|
| `lemma` | 30 |
| `theorem` | 2 |

## Readout

- No non-empty-premise proof was found; inspect action failures before scaling.

# Mathlib 4.30 Replayable-Subset Proof-Action Matrix

- Verdict: `no_nonempty_positive`
- Replay filter: `/workspace/thymic_project/paper/iclr_2/outputs/mathlib430_pretheorem_original_tactic_probe_490.json`
- Pool mode: `legacy`
- Candidate source: `retrieved_only`
- Replayable goals evaluated: 1
- Attempts: 74
- Verified attempts: 0
- Non-empty-premise verified attempts: 0
- Goals with any proof: 0
- Goals with non-empty-premise proof: 0
- Action-dependent goals: 0

## Status Counts

| Status | Count |
|---|---:|
| `search_fail` | 4 |
| `skipped_empty_action` | 5 |
| `sorry_warning` | 65 |

## By Action

| Action | Verified | Non-empty verified | Attempts |
|---|---:|---:|---:|
| `aesop_core` | 0 | 0 | 1 |
| `aesop_core_facts` | 0 | 0 | 1 |
| `aesop_core_plus_learned` | 0 | 0 | 1 |
| `aesop_core_plus_learned16` | 0 | 0 | 1 |
| `aesop_core_plus_learned16_facts` | 0 | 0 | 1 |
| `aesop_core_plus_learned16_simps` | 0 | 0 | 1 |
| `aesop_core_plus_learned32` | 0 | 0 | 1 |
| `aesop_core_plus_learned32_facts` | 0 | 0 | 1 |
| `aesop_core_plus_learned32_simps` | 0 | 0 | 1 |
| `aesop_core_plus_learned_countmatched_facts` | 0 | 0 | 1 |
| `aesop_core_plus_learned_countmatched_simps` | 0 | 0 | 1 |
| `aesop_core_plus_learned_facts` | 0 | 0 | 1 |
| `aesop_core_plus_learned_identity` | 0 | 0 | 1 |
| `aesop_core_plus_learned_random_split` | 0 | 0 | 1 |
| `aesop_core_plus_learned_simps` | 0 | 0 | 1 |
| `aesop_core_plus_learned_swapped` | 0 | 0 | 1 |
| `aesop_core_simps` | 0 | 0 | 1 |
| `aesop_empty` | 0 | 0 | 1 |
| `aesop_learned16` | 0 | 0 | 1 |
| `aesop_learned16_facts` | 0 | 0 | 1 |
| `aesop_learned16_simps` | 0 | 0 | 1 |
| `aesop_learned32` | 0 | 0 | 1 |
| `aesop_learned32_facts` | 0 | 0 | 1 |
| `aesop_learned32_simps` | 0 | 0 | 1 |
| `aesop_learned8` | 0 | 0 | 1 |
| `aesop_learned8_countmatched_facts` | 0 | 0 | 1 |
| `aesop_learned8_countmatched_simps` | 0 | 0 | 1 |
| `aesop_learned8_facts` | 0 | 0 | 1 |
| `aesop_learned8_identity` | 0 | 0 | 1 |
| `aesop_learned8_random_split` | 0 | 0 | 1 |
| `aesop_learned8_simps` | 0 | 0 | 1 |
| `aesop_learned8_swapped` | 0 | 0 | 1 |
| `hammerCore_core` | 0 | 0 | 1 |
| `hammerCore_core_plus_learned` | 0 | 0 | 1 |
| `hammerCore_core_plus_learned16` | 0 | 0 | 1 |
| `hammerCore_core_plus_learned32` | 0 | 0 | 1 |
| `hammer_core_facts` | 0 | 0 | 1 |
| `hammer_core_plus_learned` | 0 | 0 | 1 |
| `hammer_core_plus_learned16` | 0 | 0 | 1 |
| `hammer_core_plus_learned32` | 0 | 0 | 1 |
| `hammer_empty` | 0 | 0 | 1 |
| `linarith_empty` | 0 | 0 | 1 |
| `nlinarith_empty` | 0 | 0 | 1 |
| `norm_num_empty` | 0 | 0 | 1 |
| `omega_empty` | 0 | 0 | 1 |
| `ring_nf_empty` | 0 | 0 | 1 |
| `rw_core` | 0 | 0 | 1 |
| `rw_core_plus_learned` | 0 | 0 | 1 |
| `rw_core_plus_learned_then_simp` | 0 | 0 | 1 |
| `rw_core_then_simp` | 0 | 0 | 1 |
| `simp_all_core` | 0 | 0 | 1 |
| `simp_all_core_plus_learned` | 0 | 0 | 1 |
| `simp_all_core_plus_learned16` | 0 | 0 | 1 |
| `simp_all_core_plus_learned32` | 0 | 0 | 1 |
| `simp_core` | 0 | 0 | 1 |
| `simp_core_plus_learned` | 0 | 0 | 1 |
| `simp_core_plus_learned16` | 0 | 0 | 1 |
| `simp_core_plus_learned32` | 0 | 0 | 1 |
| `simp_empty` | 0 | 0 | 1 |
| `simp_only_core` | 0 | 0 | 1 |
| `simp_only_core_plus_learned` | 0 | 0 | 1 |
| `simp_rw_core` | 0 | 0 | 1 |
| `simp_rw_core_plus_learned` | 0 | 0 | 1 |
| `simp_rw_core_plus_learned_then_simp` | 0 | 0 | 1 |
| `simp_rw_core_then_simp` | 0 | 0 | 1 |
| `simpa_core` | 0 | 0 | 1 |
| `simpa_core_plus_learned` | 0 | 0 | 1 |
| `simpa_core_plus_learned16` | 0 | 0 | 1 |
| `simpa_core_plus_learned32` | 0 | 0 | 1 |
| `simpa_empty` | 0 | 0 | 1 |
| `solve_by_elim_core` | 0 | 0 | 1 |
| `solve_by_elim_core_plus_learned` | 0 | 0 | 1 |
| `solve_by_elim_core_plus_learned16` | 0 | 0 | 1 |
| `solve_by_elim_core_plus_learned32` | 0 | 0 | 1 |

## By Goal

| Goal | Verified | Non-empty verified | Empty verified | Best |
|---|---:|---:|---:|---|
| `mathlib4::MulAction.IsPretransitive.t1Space_iff` | 0 | 0 | 0 | none |

## Availability

| Goal | Checked | Available | Failed | Target/alias | Aesop-safe available | Aesop-unsafe available | Simp-safe available | Simp-unsafe available |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| `mathlib4::MulAction.IsPretransitive.t1Space_iff` | 32 | 17 | 15 | 0 | 13 | 4 | 5 | 12 |

## Candidate Audit Summary

| Metric | Count |
|---|---:|
| `aesop_safe_fact_available` | 13 |
| `aesop_unsafe_fact_available` | 4 |
| `available` | 17 |
| `learned_candidate` | 32 |
| `proof_core` | 7 |
| `selected` | 32 |
| `simp_safe_available` | 5 |
| `simp_unsafe_available` | 12 |
| `target_or_alias` | 0 |
| `unavailable` | 15 |

### By Category

| Category | Count |
|---|---:|
| `theorem_like` | 16 |
| `class` | 9 |
| `definition_like` | 4 |
| `simp_attr` | 3 |

### By Decl Kind

| Decl kind | Count |
|---|---:|
| `theorem` | 16 |
| `class` | 9 |
| `def` | 3 |
| `lemma` | 3 |
| `abbrev` | 1 |

## Readout

- No non-empty-premise proof was found; inspect action failures before scaling.

# Mathlib 4.30 Replayable-Subset Proof-Action Matrix

- Verdict: `pass_action_dependent`
- Replay filter: `/workspace/thymic_project/paper/iclr_2/outputs/mathlib430_pretheorem_original_tactic_probe_490.json`
- Pool mode: `legacy`
- Candidate source: `retrieved_only`
- Replayable goals evaluated: 1
- Attempts: 74
- Verified attempts: 27
- Non-empty-premise verified attempts: 27
- Goals with any proof: 1
- Goals with non-empty-premise proof: 1
- Action-dependent goals: 1

## Status Counts

| Status | Count |
|---|---:|
| `lean_error` | 8 |
| `proved` | 27 |
| `rewrite_fail` | 3 |
| `search_fail` | 27 |
| `simp_fail` | 4 |
| `skipped_empty_action` | 5 |

## By Action

| Action | Verified | Non-empty verified | Attempts |
|---|---:|---:|---:|
| `aesop_core` | 0 | 0 | 1 |
| `aesop_core_facts` | 0 | 0 | 1 |
| `aesop_core_plus_learned` | 1 | 1 | 1 |
| `aesop_core_plus_learned16` | 1 | 1 | 1 |
| `aesop_core_plus_learned16_facts` | 0 | 0 | 1 |
| `aesop_core_plus_learned16_simps` | 1 | 1 | 1 |
| `aesop_core_plus_learned32` | 1 | 1 | 1 |
| `aesop_core_plus_learned32_facts` | 0 | 0 | 1 |
| `aesop_core_plus_learned32_simps` | 1 | 1 | 1 |
| `aesop_core_plus_learned_countmatched_facts` | 0 | 0 | 1 |
| `aesop_core_plus_learned_countmatched_simps` | 1 | 1 | 1 |
| `aesop_core_plus_learned_facts` | 0 | 0 | 1 |
| `aesop_core_plus_learned_identity` | 1 | 1 | 1 |
| `aesop_core_plus_learned_random_split` | 1 | 1 | 1 |
| `aesop_core_plus_learned_simps` | 1 | 1 | 1 |
| `aesop_core_plus_learned_swapped` | 0 | 0 | 1 |
| `aesop_core_simps` | 0 | 0 | 1 |
| `aesop_empty` | 0 | 0 | 1 |
| `aesop_learned16` | 1 | 1 | 1 |
| `aesop_learned16_facts` | 0 | 0 | 1 |
| `aesop_learned16_simps` | 1 | 1 | 1 |
| `aesop_learned32` | 1 | 1 | 1 |
| `aesop_learned32_facts` | 0 | 0 | 1 |
| `aesop_learned32_simps` | 1 | 1 | 1 |
| `aesop_learned8` | 1 | 1 | 1 |
| `aesop_learned8_countmatched_facts` | 0 | 0 | 1 |
| `aesop_learned8_countmatched_simps` | 1 | 1 | 1 |
| `aesop_learned8_facts` | 0 | 0 | 1 |
| `aesop_learned8_identity` | 1 | 1 | 1 |
| `aesop_learned8_random_split` | 1 | 1 | 1 |
| `aesop_learned8_simps` | 1 | 1 | 1 |
| `aesop_learned8_swapped` | 0 | 0 | 1 |
| `hammerCore_core` | 0 | 0 | 1 |
| `hammerCore_core_plus_learned` | 0 | 0 | 1 |
| `hammerCore_core_plus_learned16` | 0 | 0 | 1 |
| `hammerCore_core_plus_learned32` | 0 | 0 | 1 |
| `hammer_core_facts` | 0 | 0 | 1 |
| `hammer_core_plus_learned` | 0 | 0 | 1 |
| `hammer_core_plus_learned16` | 0 | 0 | 1 |
| `hammer_core_plus_learned32` | 0 | 0 | 1 |
| `hammer_empty` | 0 | 0 | 1 |
| `linarith_empty` | 0 | 0 | 1 |
| `nlinarith_empty` | 0 | 0 | 1 |
| `norm_num_empty` | 0 | 0 | 1 |
| `omega_empty` | 0 | 0 | 1 |
| `ring_nf_empty` | 0 | 0 | 1 |
| `rw_core` | 0 | 0 | 1 |
| `rw_core_plus_learned` | 0 | 0 | 1 |
| `rw_core_plus_learned_then_simp` | 0 | 0 | 1 |
| `rw_core_then_simp` | 0 | 0 | 1 |
| `simp_all_core` | 0 | 0 | 1 |
| `simp_all_core_plus_learned` | 1 | 1 | 1 |
| `simp_all_core_plus_learned16` | 1 | 1 | 1 |
| `simp_all_core_plus_learned32` | 1 | 1 | 1 |
| `simp_core` | 0 | 0 | 1 |
| `simp_core_plus_learned` | 1 | 1 | 1 |
| `simp_core_plus_learned16` | 1 | 1 | 1 |
| `simp_core_plus_learned32` | 1 | 1 | 1 |
| `simp_empty` | 0 | 0 | 1 |
| `simp_only_core` | 0 | 0 | 1 |
| `simp_only_core_plus_learned` | 0 | 0 | 1 |
| `simp_rw_core` | 0 | 0 | 1 |
| `simp_rw_core_plus_learned` | 0 | 0 | 1 |
| `simp_rw_core_plus_learned_then_simp` | 0 | 0 | 1 |
| `simp_rw_core_then_simp` | 0 | 0 | 1 |
| `simpa_core` | 0 | 0 | 1 |
| `simpa_core_plus_learned` | 1 | 1 | 1 |
| `simpa_core_plus_learned16` | 1 | 1 | 1 |
| `simpa_core_plus_learned32` | 1 | 1 | 1 |
| `simpa_empty` | 0 | 0 | 1 |
| `solve_by_elim_core` | 0 | 0 | 1 |
| `solve_by_elim_core_plus_learned` | 0 | 0 | 1 |
| `solve_by_elim_core_plus_learned16` | 0 | 0 | 1 |
| `solve_by_elim_core_plus_learned32` | 0 | 0 | 1 |

## By Goal

| Goal | Verified | Non-empty verified | Empty verified | Best |
|---|---:|---:|---:|---|
| `mathlib4::CategoryTheory.Limits.inr_zeroCoprodIso_hom` | 27 | 27 | 0 | `simp_core_plus_learned` (0 facts, 8 simps) |

## Availability

| Goal | Checked | Available | Failed | Target/alias | Aesop-safe available | Aesop-unsafe available | Simp-safe available | Simp-unsafe available |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| `mathlib4::CategoryTheory.Limits.inr_zeroCoprodIso_hom` | 32 | 18 | 14 | 0 | 4 | 14 | 8 | 10 |

## Candidate Audit Summary

| Metric | Count |
|---|---:|
| `aesop_safe_fact_available` | 4 |
| `aesop_unsafe_fact_available` | 14 |
| `available` | 18 |
| `learned_candidate` | 32 |
| `proof_core` | 3 |
| `selected` | 32 |
| `simp_safe_available` | 8 |
| `simp_unsafe_available` | 10 |
| `target_or_alias` | 0 |
| `unavailable` | 14 |

### By Category

| Category | Count |
|---|---:|
| `definition_like` | 20 |
| `simp_attr` | 12 |

### By Decl Kind

| Decl kind | Count |
|---|---:|
| `def` | 21 |
| `theorem` | 9 |
| `abbrev` | 2 |

## Readout

- This pilot found at least one action-dependent proof, so the proof-action routing route should be scaled.

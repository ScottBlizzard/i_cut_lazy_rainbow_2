# Mathlib 4.30 Replayable-Subset Proof-Action Matrix

- Verdict: `partial_nonempty_positive`
- Replay filter: `/workspace/thymic_project/paper/iclr_2/outputs/mathlib430_pretheorem_original_tactic_probe_490.json`
- Pool mode: `legacy`
- Candidate source: `retrieved_only`
- Replayable goals evaluated: 1
- Attempts: 74
- Verified attempts: 21
- Non-empty-premise verified attempts: 15
- Goals with any proof: 1
- Goals with non-empty-premise proof: 1
- Action-dependent goals: 0

## Status Counts

| Status | Count |
|---|---:|
| `lean_error` | 16 |
| `proved` | 21 |
| `rewrite_fail` | 3 |
| `search_fail` | 9 |
| `simp_fail` | 20 |
| `skipped_empty_action` | 5 |

## By Action

| Action | Verified | Non-empty verified | Attempts |
|---|---:|---:|---:|
| `aesop_core` | 1 | 0 | 1 |
| `aesop_core_facts` | 1 | 0 | 1 |
| `aesop_core_plus_learned` | 0 | 0 | 1 |
| `aesop_core_plus_learned16` | 0 | 0 | 1 |
| `aesop_core_plus_learned16_facts` | 1 | 1 | 1 |
| `aesop_core_plus_learned16_simps` | 0 | 0 | 1 |
| `aesop_core_plus_learned32` | 0 | 0 | 1 |
| `aesop_core_plus_learned32_facts` | 1 | 1 | 1 |
| `aesop_core_plus_learned32_simps` | 0 | 0 | 1 |
| `aesop_core_plus_learned_countmatched_facts` | 1 | 1 | 1 |
| `aesop_core_plus_learned_countmatched_simps` | 0 | 0 | 1 |
| `aesop_core_plus_learned_facts` | 1 | 1 | 1 |
| `aesop_core_plus_learned_identity` | 0 | 0 | 1 |
| `aesop_core_plus_learned_random_split` | 1 | 1 | 1 |
| `aesop_core_plus_learned_simps` | 0 | 0 | 1 |
| `aesop_core_plus_learned_swapped` | 1 | 1 | 1 |
| `aesop_core_simps` | 1 | 0 | 1 |
| `aesop_empty` | 1 | 0 | 1 |
| `aesop_learned16` | 0 | 0 | 1 |
| `aesop_learned16_facts` | 1 | 1 | 1 |
| `aesop_learned16_simps` | 0 | 0 | 1 |
| `aesop_learned32` | 0 | 0 | 1 |
| `aesop_learned32_facts` | 1 | 1 | 1 |
| `aesop_learned32_simps` | 0 | 0 | 1 |
| `aesop_learned8` | 0 | 0 | 1 |
| `aesop_learned8_countmatched_facts` | 1 | 1 | 1 |
| `aesop_learned8_countmatched_simps` | 0 | 0 | 1 |
| `aesop_learned8_facts` | 1 | 1 | 1 |
| `aesop_learned8_identity` | 0 | 0 | 1 |
| `aesop_learned8_random_split` | 1 | 1 | 1 |
| `aesop_learned8_simps` | 0 | 0 | 1 |
| `aesop_learned8_swapped` | 1 | 1 | 1 |
| `hammerCore_core` | 0 | 0 | 1 |
| `hammerCore_core_plus_learned` | 0 | 0 | 1 |
| `hammerCore_core_plus_learned16` | 0 | 0 | 1 |
| `hammerCore_core_plus_learned32` | 0 | 0 | 1 |
| `hammer_core_facts` | 1 | 0 | 1 |
| `hammer_core_plus_learned` | 1 | 1 | 1 |
| `hammer_core_plus_learned16` | 1 | 1 | 1 |
| `hammer_core_plus_learned32` | 1 | 1 | 1 |
| `hammer_empty` | 1 | 0 | 1 |
| `linarith_empty` | 0 | 0 | 1 |
| `nlinarith_empty` | 0 | 0 | 1 |
| `norm_num_empty` | 0 | 0 | 1 |
| `omega_empty` | 0 | 0 | 1 |
| `ring_nf_empty` | 0 | 0 | 1 |
| `rw_core` | 0 | 0 | 1 |
| `rw_core_plus_learned` | 0 | 0 | 1 |
| `rw_core_plus_learned_then_simp` | 0 | 0 | 1 |
| `rw_core_then_simp` | 0 | 0 | 1 |
| `simp_all_core` | 0 | 0 | 1 |
| `simp_all_core_plus_learned` | 0 | 0 | 1 |
| `simp_all_core_plus_learned16` | 0 | 0 | 1 |
| `simp_all_core_plus_learned32` | 0 | 0 | 1 |
| `simp_core` | 0 | 0 | 1 |
| `simp_core_plus_learned` | 0 | 0 | 1 |
| `simp_core_plus_learned16` | 0 | 0 | 1 |
| `simp_core_plus_learned32` | 0 | 0 | 1 |
| `simp_empty` | 0 | 0 | 1 |
| `simp_only_core` | 0 | 0 | 1 |
| `simp_only_core_plus_learned` | 0 | 0 | 1 |
| `simp_rw_core` | 0 | 0 | 1 |
| `simp_rw_core_plus_learned` | 0 | 0 | 1 |
| `simp_rw_core_plus_learned_then_simp` | 0 | 0 | 1 |
| `simp_rw_core_then_simp` | 0 | 0 | 1 |
| `simpa_core` | 0 | 0 | 1 |
| `simpa_core_plus_learned` | 0 | 0 | 1 |
| `simpa_core_plus_learned16` | 0 | 0 | 1 |
| `simpa_core_plus_learned32` | 0 | 0 | 1 |
| `simpa_empty` | 0 | 0 | 1 |
| `solve_by_elim_core` | 0 | 0 | 1 |
| `solve_by_elim_core_plus_learned` | 0 | 0 | 1 |
| `solve_by_elim_core_plus_learned16` | 0 | 0 | 1 |
| `solve_by_elim_core_plus_learned32` | 0 | 0 | 1 |

## By Goal

| Goal | Verified | Non-empty verified | Empty verified | Best |
|---|---:|---:|---:|---|
| `mathlib4::Submodule.restrictScalars_sInf` | 21 | 15 | 6 | `hammer_empty` (0 facts, 0 simps) |

## Availability

| Goal | Checked | Available | Failed | Target/alias | Aesop-safe available | Aesop-unsafe available | Simp-safe available | Simp-unsafe available |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| `mathlib4::Submodule.restrictScalars_sInf` | 32 | 14 | 18 | 0 | 9 | 5 | 6 | 8 |

## Candidate Audit Summary

| Metric | Count |
|---|---:|
| `aesop_safe_fact_available` | 9 |
| `aesop_unsafe_fact_available` | 5 |
| `available` | 14 |
| `learned_candidate` | 32 |
| `proof_core` | 3 |
| `selected` | 32 |
| `simp_safe_available` | 6 |
| `simp_unsafe_available` | 8 |
| `target_or_alias` | 0 |
| `unavailable` | 18 |

### By Category

| Category | Count |
|---|---:|
| `theorem_like` | 17 |
| `simp_attr` | 8 |
| `definition_like` | 6 |
| `structure` | 1 |

### By Decl Kind

| Decl kind | Count |
|---|---:|
| `theorem` | 19 |
| `def` | 9 |
| `lemma` | 3 |
| `structure` | 1 |

## Readout

- Non-empty-premise proofs exist, but empty baselines also solve those goals; scale cautiously and separate easy goals.

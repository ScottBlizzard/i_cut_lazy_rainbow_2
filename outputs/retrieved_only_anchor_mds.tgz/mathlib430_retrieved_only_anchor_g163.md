# Mathlib 4.30 Replayable-Subset Proof-Action Matrix

- Verdict: `no_nonempty_positive`
- Replay filter: `/workspace/thymic_project/paper/iclr_2/outputs/mathlib430_pretheorem_original_tactic_probe_490.json`
- Pool mode: `legacy`
- Candidate source: `retrieved_only`
- Replayable goals evaluated: 1
- Attempts: 74
- Verified attempts: 0
- Non-empty-premise verified attempts: 0
- Goals with any proof: 0
- Goals with non-empty-premise proof: 0
- Action-dependent goals: 0

## Status Counts

| Status | Count |
|---|---:|
| `lean_error` | 11 |
| `rewrite_fail` | 4 |
| `search_fail` | 40 |
| `simp_fail` | 14 |
| `skipped_empty_action` | 5 |

## By Action

| Action | Verified | Non-empty verified | Attempts |
|---|---:|---:|---:|
| `aesop_core` | 0 | 0 | 1 |
| `aesop_core_facts` | 0 | 0 | 1 |
| `aesop_core_plus_learned` | 0 | 0 | 1 |
| `aesop_core_plus_learned16` | 0 | 0 | 1 |
| `aesop_core_plus_learned16_facts` | 0 | 0 | 1 |
| `aesop_core_plus_learned16_simps` | 0 | 0 | 1 |
| `aesop_core_plus_learned32` | 0 | 0 | 1 |
| `aesop_core_plus_learned32_facts` | 0 | 0 | 1 |
| `aesop_core_plus_learned32_simps` | 0 | 0 | 1 |
| `aesop_core_plus_learned_countmatched_facts` | 0 | 0 | 1 |
| `aesop_core_plus_learned_countmatched_simps` | 0 | 0 | 1 |
| `aesop_core_plus_learned_facts` | 0 | 0 | 1 |
| `aesop_core_plus_learned_identity` | 0 | 0 | 1 |
| `aesop_core_plus_learned_random_split` | 0 | 0 | 1 |
| `aesop_core_plus_learned_simps` | 0 | 0 | 1 |
| `aesop_core_plus_learned_swapped` | 0 | 0 | 1 |
| `aesop_core_simps` | 0 | 0 | 1 |
| `aesop_empty` | 0 | 0 | 1 |
| `aesop_learned16` | 0 | 0 | 1 |
| `aesop_learned16_facts` | 0 | 0 | 1 |
| `aesop_learned16_simps` | 0 | 0 | 1 |
| `aesop_learned32` | 0 | 0 | 1 |
| `aesop_learned32_facts` | 0 | 0 | 1 |
| `aesop_learned32_simps` | 0 | 0 | 1 |
| `aesop_learned8` | 0 | 0 | 1 |
| `aesop_learned8_countmatched_facts` | 0 | 0 | 1 |
| `aesop_learned8_countmatched_simps` | 0 | 0 | 1 |
| `aesop_learned8_facts` | 0 | 0 | 1 |
| `aesop_learned8_identity` | 0 | 0 | 1 |
| `aesop_learned8_random_split` | 0 | 0 | 1 |
| `aesop_learned8_simps` | 0 | 0 | 1 |
| `aesop_learned8_swapped` | 0 | 0 | 1 |
| `hammerCore_core` | 0 | 0 | 1 |
| `hammerCore_core_plus_learned` | 0 | 0 | 1 |
| `hammerCore_core_plus_learned16` | 0 | 0 | 1 |
| `hammerCore_core_plus_learned32` | 0 | 0 | 1 |
| `hammer_core_facts` | 0 | 0 | 1 |
| `hammer_core_plus_learned` | 0 | 0 | 1 |
| `hammer_core_plus_learned16` | 0 | 0 | 1 |
| `hammer_core_plus_learned32` | 0 | 0 | 1 |
| `hammer_empty` | 0 | 0 | 1 |
| `linarith_empty` | 0 | 0 | 1 |
| `nlinarith_empty` | 0 | 0 | 1 |
| `norm_num_empty` | 0 | 0 | 1 |
| `omega_empty` | 0 | 0 | 1 |
| `ring_nf_empty` | 0 | 0 | 1 |
| `rw_core` | 0 | 0 | 1 |
| `rw_core_plus_learned` | 0 | 0 | 1 |
| `rw_core_plus_learned_then_simp` | 0 | 0 | 1 |
| `rw_core_then_simp` | 0 | 0 | 1 |
| `simp_all_core` | 0 | 0 | 1 |
| `simp_all_core_plus_learned` | 0 | 0 | 1 |
| `simp_all_core_plus_learned16` | 0 | 0 | 1 |
| `simp_all_core_plus_learned32` | 0 | 0 | 1 |
| `simp_core` | 0 | 0 | 1 |
| `simp_core_plus_learned` | 0 | 0 | 1 |
| `simp_core_plus_learned16` | 0 | 0 | 1 |
| `simp_core_plus_learned32` | 0 | 0 | 1 |
| `simp_empty` | 0 | 0 | 1 |
| `simp_only_core` | 0 | 0 | 1 |
| `simp_only_core_plus_learned` | 0 | 0 | 1 |
| `simp_rw_core` | 0 | 0 | 1 |
| `simp_rw_core_plus_learned` | 0 | 0 | 1 |
| `simp_rw_core_plus_learned_then_simp` | 0 | 0 | 1 |
| `simp_rw_core_then_simp` | 0 | 0 | 1 |
| `simpa_core` | 0 | 0 | 1 |
| `simpa_core_plus_learned` | 0 | 0 | 1 |
| `simpa_core_plus_learned16` | 0 | 0 | 1 |
| `simpa_core_plus_learned32` | 0 | 0 | 1 |
| `simpa_empty` | 0 | 0 | 1 |
| `solve_by_elim_core` | 0 | 0 | 1 |
| `solve_by_elim_core_plus_learned` | 0 | 0 | 1 |
| `solve_by_elim_core_plus_learned16` | 0 | 0 | 1 |
| `solve_by_elim_core_plus_learned32` | 0 | 0 | 1 |

## By Goal

| Goal | Verified | Non-empty verified | Empty verified | Best |
|---|---:|---:|---:|---|
| `mathlib4::CategoryTheory.NatTrans.app_sum` | 0 | 0 | 0 | none |

## Availability

| Goal | Checked | Available | Failed | Target/alias | Aesop-safe available | Aesop-unsafe available | Simp-safe available | Simp-unsafe available |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| `mathlib4::CategoryTheory.NatTrans.app_sum` | 32 | 9 | 23 | 0 | 1 | 8 | 5 | 4 |

## Candidate Audit Summary

| Metric | Count |
|---|---:|
| `aesop_safe_fact_available` | 1 |
| `aesop_unsafe_fact_available` | 8 |
| `available` | 9 |
| `learned_candidate` | 32 |
| `proof_core` | 1 |
| `selected` | 32 |
| `simp_safe_available` | 5 |
| `simp_unsafe_available` | 4 |
| `target_or_alias` | 0 |
| `unavailable` | 23 |

### By Category

| Category | Count |
|---|---:|
| `simp_attr` | 23 |
| `definition_like` | 4 |
| `structure` | 3 |
| `class` | 1 |
| `theorem_like` | 1 |

### By Decl Kind

| Decl kind | Count |
|---|---:|
| `def` | 27 |
| `structure` | 3 |
| `class` | 1 |
| `theorem` | 1 |

## Readout

- No non-empty-premise proof was found; inspect action failures before scaling.

# Mathlib 4.30 Replayable-Subset Proof-Action Matrix

- Verdict: `no_nonempty_positive`
- Replay filter: `/workspace/thymic_project/paper/iclr_2/outputs/mathlib430_pretheorem_original_tactic_probe_490.json`
- Pool mode: `legacy`
- Candidate source: `retrieved_only`
- Replayable goals evaluated: 1
- Attempts: 74
- Verified attempts: 0
- Non-empty-premise verified attempts: 0
- Goals with any proof: 0
- Goals with non-empty-premise proof: 0
- Action-dependent goals: 0

## Status Counts

| Status | Count |
|---|---:|
| `lean_error` | 21 |
| `rewrite_fail` | 3 |
| `search_fail` | 30 |
| `simp_fail` | 15 |
| `skipped_empty_action` | 5 |

## By Action

| Action | Verified | Non-empty verified | Attempts |
|---|---:|---:|---:|
| `aesop_core` | 0 | 0 | 1 |
| `aesop_core_facts` | 0 | 0 | 1 |
| `aesop_core_plus_learned` | 0 | 0 | 1 |
| `aesop_core_plus_learned16` | 0 | 0 | 1 |
| `aesop_core_plus_learned16_facts` | 0 | 0 | 1 |
| `aesop_core_plus_learned16_simps` | 0 | 0 | 1 |
| `aesop_core_plus_learned32` | 0 | 0 | 1 |
| `aesop_core_plus_learned32_facts` | 0 | 0 | 1 |
| `aesop_core_plus_learned32_simps` | 0 | 0 | 1 |
| `aesop_core_plus_learned_countmatched_facts` | 0 | 0 | 1 |
| `aesop_core_plus_learned_countmatched_simps` | 0 | 0 | 1 |
| `aesop_core_plus_learned_facts` | 0 | 0 | 1 |
| `aesop_core_plus_learned_identity` | 0 | 0 | 1 |
| `aesop_core_plus_learned_random_split` | 0 | 0 | 1 |
| `aesop_core_plus_learned_simps` | 0 | 0 | 1 |
| `aesop_core_plus_learned_swapped` | 0 | 0 | 1 |
| `aesop_core_simps` | 0 | 0 | 1 |
| `aesop_empty` | 0 | 0 | 1 |
| `aesop_learned16` | 0 | 0 | 1 |
| `aesop_learned16_facts` | 0 | 0 | 1 |
| `aesop_learned16_simps` | 0 | 0 | 1 |
| `aesop_learned32` | 0 | 0 | 1 |
| `aesop_learned32_facts` | 0 | 0 | 1 |
| `aesop_learned32_simps` | 0 | 0 | 1 |
| `aesop_learned8` | 0 | 0 | 1 |
| `aesop_learned8_countmatched_facts` | 0 | 0 | 1 |
| `aesop_learned8_countmatched_simps` | 0 | 0 | 1 |
| `aesop_learned8_facts` | 0 | 0 | 1 |
| `aesop_learned8_identity` | 0 | 0 | 1 |
| `aesop_learned8_random_split` | 0 | 0 | 1 |
| `aesop_learned8_simps` | 0 | 0 | 1 |
| `aesop_learned8_swapped` | 0 | 0 | 1 |
| `hammerCore_core` | 0 | 0 | 1 |
| `hammerCore_core_plus_learned` | 0 | 0 | 1 |
| `hammerCore_core_plus_learned16` | 0 | 0 | 1 |
| `hammerCore_core_plus_learned32` | 0 | 0 | 1 |
| `hammer_core_facts` | 0 | 0 | 1 |
| `hammer_core_plus_learned` | 0 | 0 | 1 |
| `hammer_core_plus_learned16` | 0 | 0 | 1 |
| `hammer_core_plus_learned32` | 0 | 0 | 1 |
| `hammer_empty` | 0 | 0 | 1 |
| `linarith_empty` | 0 | 0 | 1 |
| `nlinarith_empty` | 0 | 0 | 1 |
| `norm_num_empty` | 0 | 0 | 1 |
| `omega_empty` | 0 | 0 | 1 |
| `ring_nf_empty` | 0 | 0 | 1 |
| `rw_core` | 0 | 0 | 1 |
| `rw_core_plus_learned` | 0 | 0 | 1 |
| `rw_core_plus_learned_then_simp` | 0 | 0 | 1 |
| `rw_core_then_simp` | 0 | 0 | 1 |
| `simp_all_core` | 0 | 0 | 1 |
| `simp_all_core_plus_learned` | 0 | 0 | 1 |
| `simp_all_core_plus_learned16` | 0 | 0 | 1 |
| `simp_all_core_plus_learned32` | 0 | 0 | 1 |
| `simp_core` | 0 | 0 | 1 |
| `simp_core_plus_learned` | 0 | 0 | 1 |
| `simp_core_plus_learned16` | 0 | 0 | 1 |
| `simp_core_plus_learned32` | 0 | 0 | 1 |
| `simp_empty` | 0 | 0 | 1 |
| `simp_only_core` | 0 | 0 | 1 |
| `simp_only_core_plus_learned` | 0 | 0 | 1 |
| `simp_rw_core` | 0 | 0 | 1 |
| `simp_rw_core_plus_learned` | 0 | 0 | 1 |
| `simp_rw_core_plus_learned_then_simp` | 0 | 0 | 1 |
| `simp_rw_core_then_simp` | 0 | 0 | 1 |
| `simpa_core` | 0 | 0 | 1 |
| `simpa_core_plus_learned` | 0 | 0 | 1 |
| `simpa_core_plus_learned16` | 0 | 0 | 1 |
| `simpa_core_plus_learned32` | 0 | 0 | 1 |
| `simpa_empty` | 0 | 0 | 1 |
| `solve_by_elim_core` | 0 | 0 | 1 |
| `solve_by_elim_core_plus_learned` | 0 | 0 | 1 |
| `solve_by_elim_core_plus_learned16` | 0 | 0 | 1 |
| `solve_by_elim_core_plus_learned32` | 0 | 0 | 1 |

## By Goal

| Goal | Verified | Non-empty verified | Empty verified | Best |
|---|---:|---:|---:|---|
| `mathlib4::Stream'.Seq.length_map` | 0 | 0 | 0 | none |

## Availability

| Goal | Checked | Available | Failed | Target/alias | Aesop-safe available | Aesop-unsafe available | Simp-safe available | Simp-unsafe available |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| `mathlib4::Stream'.Seq.length_map` | 32 | 14 | 18 | 0 | 2 | 12 | 4 | 10 |

## Candidate Audit Summary

| Metric | Count |
|---|---:|
| `aesop_safe_fact_available` | 2 |
| `aesop_unsafe_fact_available` | 12 |
| `available` | 14 |
| `learned_candidate` | 32 |
| `proof_core` | 3 |
| `selected` | 32 |
| `simp_safe_available` | 4 |
| `simp_unsafe_available` | 10 |
| `target_or_alias` | 0 |
| `unavailable` | 18 |

### By Category

| Category | Count |
|---|---:|
| `definition_like` | 20 |
| `simp_attr` | 6 |
| `theorem_like` | 5 |
| `class` | 1 |

### By Decl Kind

| Decl kind | Count |
|---|---:|
| `def` | 20 |
| `theorem` | 10 |
| `class` | 1 |
| `lemma` | 1 |

## Readout

- No non-empty-premise proof was found; inspect action failures before scaling.

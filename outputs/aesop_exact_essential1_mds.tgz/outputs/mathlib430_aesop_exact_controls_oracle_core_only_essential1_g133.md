# Mathlib 4.30 Replayable-Subset Proof-Action Matrix

- Verdict: `pass_action_dependent`
- Replay filter: `/workspace/thymic_project/paper/iclr_2/outputs/mathlib430_pretheorem_original_tactic_probe_490.json`
- Pool mode: `legacy`
- Candidate source: `oracle_core_only`
- Result action suffix: `_oracle_core_only_exact`
- Replayable goals evaluated: 1
- Attempts: 9
- Verified attempts: 3
- Non-empty-premise verified attempts: 3
- Goals with any proof: 1
- Goals with non-empty-premise proof: 1
- Action-dependent goals: 1

## Status Counts

| Status | Count |
|---|---:|
| `lean_error` | 3 |
| `proved` | 3 |
| `search_fail` | 1 |
| `simp_fail` | 2 |

## By Action

| Action | Verified | Non-empty verified | Attempts |
|---|---:|---:|---:|
| `aesop_core_plus_learned_countmatched_facts_oracle_core_only_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_countmatched_simps_oracle_core_only_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_facts_oracle_core_only_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_identity_oracle_core_only_exact` | 1 | 1 | 1 |
| `aesop_core_plus_learned_oracle_core_only_exact` | 1 | 1 | 1 |
| `aesop_core_plus_learned_random_split_oracle_core_only_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_simps_oracle_core_only_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_swapped_oracle_core_only_exact` | 1 | 1 | 1 |
| `aesop_empty_oracle_core_only_exact` | 0 | 0 | 1 |

## By Goal

| Goal | Verified | Non-empty verified | Empty verified | Best |
|---|---:|---:|---:|---|
| `mathlib4::NormedAddCommGroup.summable_imp_tendsto_of_complete` | 3 | 3 | 0 | `aesop_core_plus_learned_oracle_core_only_exact` (6 facts, 6 simps) |

## Availability

| Goal | Checked | Available | Failed | Target/alias | Aesop-safe available | Aesop-unsafe available | Simp-safe available | Simp-unsafe available |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| `mathlib4::NormedAddCommGroup.summable_imp_tendsto_of_complete` | 6 | 6 | 0 | 0 | 2 | 4 | 2 | 4 |

## Candidate Audit Summary

| Metric | Count |
|---|---:|
| `aesop_safe_fact_available` | 2 |
| `aesop_unsafe_fact_available` | 4 |
| `available` | 6 |
| `learned_candidate` | 6 |
| `proof_core` | 6 |
| `selected` | 6 |
| `simp_safe_available` | 2 |
| `simp_unsafe_available` | 4 |
| `target_or_alias` | 0 |
| `unavailable` | 0 |

### By Category

| Category | Count |
|---|---:|
| `definition_like` | 3 |
| `theorem_like` | 2 |
| `class` | 1 |

### By Decl Kind

| Decl kind | Count |
|---|---:|
| `def` | 3 |
| `theorem` | 2 |
| `class` | 1 |

## Readout

- This pilot found at least one action-dependent proof, so the proof-action routing route should be scaled.

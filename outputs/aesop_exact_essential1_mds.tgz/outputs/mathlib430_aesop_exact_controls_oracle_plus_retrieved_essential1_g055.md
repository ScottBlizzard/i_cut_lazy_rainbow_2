# Mathlib 4.30 Replayable-Subset Proof-Action Matrix

- Verdict: `partial_nonempty_positive`
- Replay filter: `/workspace/thymic_project/paper/iclr_2/outputs/mathlib430_pretheorem_original_tactic_probe_490.json`
- Pool mode: `legacy`
- Candidate source: `oracle_plus_retrieved`
- Result action suffix: `_oracle_plus_retrieved_exact`
- Replayable goals evaluated: 1
- Attempts: 9
- Verified attempts: 9
- Non-empty-premise verified attempts: 8
- Goals with any proof: 1
- Goals with non-empty-premise proof: 1
- Action-dependent goals: 0

## Status Counts

| Status | Count |
|---|---:|
| `proved` | 9 |

## By Action

| Action | Verified | Non-empty verified | Attempts |
|---|---:|---:|---:|
| `aesop_core_plus_learned_countmatched_facts_oracle_plus_retrieved_exact` | 1 | 1 | 1 |
| `aesop_core_plus_learned_countmatched_simps_oracle_plus_retrieved_exact` | 1 | 1 | 1 |
| `aesop_core_plus_learned_facts_oracle_plus_retrieved_exact` | 1 | 1 | 1 |
| `aesop_core_plus_learned_identity_oracle_plus_retrieved_exact` | 1 | 1 | 1 |
| `aesop_core_plus_learned_oracle_plus_retrieved_exact` | 1 | 1 | 1 |
| `aesop_core_plus_learned_random_split_oracle_plus_retrieved_exact` | 1 | 1 | 1 |
| `aesop_core_plus_learned_simps_oracle_plus_retrieved_exact` | 1 | 1 | 1 |
| `aesop_core_plus_learned_swapped_oracle_plus_retrieved_exact` | 1 | 1 | 1 |
| `aesop_empty_oracle_plus_retrieved_exact` | 1 | 0 | 1 |

## By Goal

| Goal | Verified | Non-empty verified | Empty verified | Best |
|---|---:|---:|---:|---|
| `mathlib4::Seminorm.ball_sup` | 9 | 8 | 1 | `aesop_empty_oracle_plus_retrieved_exact` (0 facts, 0 simps) |

## Availability

| Goal | Checked | Available | Failed | Target/alias | Aesop-safe available | Aesop-unsafe available | Simp-safe available | Simp-unsafe available |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| `mathlib4::Seminorm.ball_sup` | 34 | 22 | 12 | 0 | 15 | 7 | 8 | 14 |

## Candidate Audit Summary

| Metric | Count |
|---|---:|
| `aesop_safe_fact_available` | 15 |
| `aesop_unsafe_fact_available` | 7 |
| `available` | 22 |
| `learned_candidate` | 32 |
| `proof_core` | 5 |
| `selected` | 34 |
| `simp_safe_available` | 8 |
| `simp_unsafe_available` | 14 |
| `target_or_alias` | 0 |
| `unavailable` | 12 |

### By Category

| Category | Count |
|---|---:|
| `theorem_like` | 17 |
| `simp_attr` | 9 |
| `definition_like` | 5 |
| `proof_core_only_unknown` | 2 |
| `structure` | 1 |

### By Decl Kind

| Decl kind | Count |
|---|---:|
| `theorem` | 19 |
| `lemma` | 7 |
| `def` | 4 |
| `proof_core_only` | 2 |
| `abbrev` | 1 |
| `structure` | 1 |

## Readout

- Non-empty-premise proofs exist, but empty baselines also solve those goals; scale cautiously and separate easy goals.

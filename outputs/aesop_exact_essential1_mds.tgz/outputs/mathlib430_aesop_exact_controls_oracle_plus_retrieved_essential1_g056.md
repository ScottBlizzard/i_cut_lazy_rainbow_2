# Mathlib 4.30 Replayable-Subset Proof-Action Matrix

- Verdict: `no_nonempty_positive`
- Replay filter: `/workspace/thymic_project/paper/iclr_2/outputs/mathlib430_pretheorem_original_tactic_probe_490.json`
- Pool mode: `legacy`
- Candidate source: `oracle_plus_retrieved`
- Result action suffix: `_oracle_plus_retrieved_exact`
- Replayable goals evaluated: 1
- Attempts: 9
- Verified attempts: 0
- Non-empty-premise verified attempts: 0
- Goals with any proof: 0
- Goals with non-empty-premise proof: 0
- Action-dependent goals: 0

## Status Counts

| Status | Count |
|---|---:|
| `search_fail` | 1 |
| `simp_fail` | 8 |

## By Action

| Action | Verified | Non-empty verified | Attempts |
|---|---:|---:|---:|
| `aesop_core_plus_learned_countmatched_facts_oracle_plus_retrieved_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_countmatched_simps_oracle_plus_retrieved_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_facts_oracle_plus_retrieved_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_identity_oracle_plus_retrieved_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_oracle_plus_retrieved_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_random_split_oracle_plus_retrieved_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_simps_oracle_plus_retrieved_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_swapped_oracle_plus_retrieved_exact` | 0 | 0 | 1 |
| `aesop_empty_oracle_plus_retrieved_exact` | 0 | 0 | 1 |

## By Goal

| Goal | Verified | Non-empty verified | Empty verified | Best |
|---|---:|---:|---:|---|
| `mathlib4::Submodule.Quotient.LinearMap.range_eq_top_of_cancel` | 0 | 0 | 0 | none |

## Availability

| Goal | Checked | Available | Failed | Target/alias | Aesop-safe available | Aesop-unsafe available | Simp-safe available | Simp-unsafe available |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| `mathlib4::Submodule.Quotient.LinearMap.range_eq_top_of_cancel` | 32 | 7 | 25 | 1 | 5 | 2 | 3 | 4 |

## Candidate Audit Summary

| Metric | Count |
|---|---:|
| `aesop_safe_fact_available` | 5 |
| `aesop_unsafe_fact_available` | 2 |
| `available` | 7 |
| `learned_candidate` | 32 |
| `proof_core` | 2 |
| `selected` | 32 |
| `simp_safe_available` | 3 |
| `simp_unsafe_available` | 4 |
| `target_or_alias` | 1 |
| `unavailable` | 25 |

### By Category

| Category | Count |
|---|---:|
| `simp_attr` | 12 |
| `definition_like` | 10 |
| `theorem_like` | 10 |

### By Decl Kind

| Decl kind | Count |
|---|---:|
| `theorem` | 20 |
| `def` | 9 |
| `lemma` | 2 |
| `abbrev` | 1 |

## Readout

- No non-empty-premise proof was found; inspect action failures before scaling.

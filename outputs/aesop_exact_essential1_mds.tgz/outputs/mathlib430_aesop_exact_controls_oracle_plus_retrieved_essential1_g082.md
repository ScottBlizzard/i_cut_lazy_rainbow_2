# Mathlib 4.30 Replayable-Subset Proof-Action Matrix

- Verdict: `no_nonempty_positive`
- Replay filter: `/workspace/thymic_project/paper/iclr_2/outputs/mathlib430_pretheorem_original_tactic_probe_490.json`
- Pool mode: `legacy`
- Candidate source: `oracle_plus_retrieved`
- Result action suffix: `_oracle_plus_retrieved_exact`
- Replayable goals evaluated: 1
- Attempts: 9
- Verified attempts: 0
- Non-empty-premise verified attempts: 0
- Goals with any proof: 0
- Goals with non-empty-premise proof: 0
- Action-dependent goals: 0

## Status Counts

| Status | Count |
|---|---:|
| `lean_error` | 1 |
| `simp_fail` | 8 |

## By Action

| Action | Verified | Non-empty verified | Attempts |
|---|---:|---:|---:|
| `aesop_core_plus_learned_countmatched_facts_oracle_plus_retrieved_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_countmatched_simps_oracle_plus_retrieved_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_facts_oracle_plus_retrieved_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_identity_oracle_plus_retrieved_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_oracle_plus_retrieved_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_random_split_oracle_plus_retrieved_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_simps_oracle_plus_retrieved_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_swapped_oracle_plus_retrieved_exact` | 0 | 0 | 1 |
| `aesop_empty_oracle_plus_retrieved_exact` | 0 | 0 | 1 |

## By Goal

| Goal | Verified | Non-empty verified | Empty verified | Best |
|---|---:|---:|---:|---|
| `mathlib4::EuclideanGeometry.Sphere.dist_orthogonalProjection_eq_radius_iff_isTangentAt` | 0 | 0 | 0 | none |

## Availability

| Goal | Checked | Available | Failed | Target/alias | Aesop-safe available | Aesop-unsafe available | Simp-safe available | Simp-unsafe available |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| `mathlib4::EuclideanGeometry.Sphere.dist_orthogonalProjection_eq_radius_iff_isTangentAt` | 34 | 21 | 13 | 0 | 14 | 7 | 5 | 16 |

## Candidate Audit Summary

| Metric | Count |
|---|---:|
| `aesop_safe_fact_available` | 14 |
| `aesop_unsafe_fact_available` | 7 |
| `available` | 21 |
| `learned_candidate` | 32 |
| `proof_core` | 9 |
| `selected` | 34 |
| `simp_safe_available` | 5 |
| `simp_unsafe_available` | 16 |
| `target_or_alias` | 0 |
| `unavailable` | 13 |

### By Category

| Category | Count |
|---|---:|
| `theorem_like` | 14 |
| `definition_like` | 9 |
| `structure` | 5 |
| `simp_attr` | 4 |
| `proof_core_only_unknown` | 2 |

### By Decl Kind

| Decl kind | Count |
|---|---:|
| `theorem` | 11 |
| `def` | 9 |
| `lemma` | 7 |
| `structure` | 5 |
| `proof_core_only` | 2 |

## Readout

- No non-empty-premise proof was found; inspect action failures before scaling.

# Mathlib 4.30 Replayable-Subset Proof-Action Matrix

- Verdict: `no_nonempty_positive`
- Replay filter: `/workspace/thymic_project/paper/iclr_2/outputs/mathlib430_pretheorem_original_tactic_probe_490.json`
- Pool mode: `legacy`
- Candidate source: `oracle_plus_retrieved`
- Result action suffix: `_oracle_plus_retrieved_exact`
- Replayable goals evaluated: 1
- Attempts: 9
- Verified attempts: 0
- Non-empty-premise verified attempts: 0
- Goals with any proof: 0
- Goals with non-empty-premise proof: 0
- Action-dependent goals: 0

## Status Counts

| Status | Count |
|---|---:|
| `sorry_warning` | 9 |

## By Action

| Action | Verified | Non-empty verified | Attempts |
|---|---:|---:|---:|
| `aesop_core_plus_learned_countmatched_facts_oracle_plus_retrieved_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_countmatched_simps_oracle_plus_retrieved_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_facts_oracle_plus_retrieved_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_identity_oracle_plus_retrieved_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_oracle_plus_retrieved_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_random_split_oracle_plus_retrieved_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_simps_oracle_plus_retrieved_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_swapped_oracle_plus_retrieved_exact` | 0 | 0 | 1 |
| `aesop_empty_oracle_plus_retrieved_exact` | 0 | 0 | 1 |

## By Goal

| Goal | Verified | Non-empty verified | Empty verified | Best |
|---|---:|---:|---:|---|
| `mathlib4::IsUltrametricDist.norm_tprod_le_of_forall_le_of_nonneg` | 0 | 0 | 0 | none |

## Availability

| Goal | Checked | Available | Failed | Target/alias | Aesop-safe available | Aesop-unsafe available | Simp-safe available | Simp-unsafe available |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| `mathlib4::IsUltrametricDist.norm_tprod_le_of_forall_le_of_nonneg` | 32 | 20 | 12 | 0 | 18 | 2 | 2 | 18 |

## Candidate Audit Summary

| Metric | Count |
|---|---:|
| `aesop_safe_fact_available` | 18 |
| `aesop_unsafe_fact_available` | 2 |
| `available` | 20 |
| `learned_candidate` | 32 |
| `proof_core` | 4 |
| `selected` | 32 |
| `simp_safe_available` | 2 |
| `simp_unsafe_available` | 18 |
| `target_or_alias` | 0 |
| `unavailable` | 12 |

### By Category

| Category | Count |
|---|---:|
| `theorem_like` | 26 |
| `definition_like` | 3 |
| `simp_attr` | 3 |

### By Decl Kind

| Decl kind | Count |
|---|---:|
| `theorem` | 24 |
| `lemma` | 5 |
| `def` | 3 |

## Readout

- No non-empty-premise proof was found; inspect action failures before scaling.

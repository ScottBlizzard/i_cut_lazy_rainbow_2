# Mathlib 4.30 Replayable-Subset Proof-Action Matrix

- Verdict: `no_nonempty_positive`
- Replay filter: `/workspace/thymic_project/paper/iclr_2/outputs/mathlib430_pretheorem_original_tactic_probe_490.json`
- Pool mode: `legacy`
- Candidate source: `oracle_plus_retrieved`
- Result action suffix: `_oracle_plus_retrieved_exact`
- Replayable goals evaluated: 1
- Attempts: 9
- Verified attempts: 0
- Non-empty-premise verified attempts: 0
- Goals with any proof: 0
- Goals with non-empty-premise proof: 0
- Action-dependent goals: 0

## Status Counts

| Status | Count |
|---|---:|
| `search_fail` | 3 |
| `simp_fail` | 6 |

## By Action

| Action | Verified | Non-empty verified | Attempts |
|---|---:|---:|---:|
| `aesop_core_plus_learned_countmatched_facts_oracle_plus_retrieved_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_countmatched_simps_oracle_plus_retrieved_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_facts_oracle_plus_retrieved_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_identity_oracle_plus_retrieved_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_oracle_plus_retrieved_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_random_split_oracle_plus_retrieved_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_simps_oracle_plus_retrieved_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_swapped_oracle_plus_retrieved_exact` | 0 | 0 | 1 |
| `aesop_empty_oracle_plus_retrieved_exact` | 0 | 0 | 1 |

## By Goal

| Goal | Verified | Non-empty verified | Empty verified | Best |
|---|---:|---:|---:|---|
| `mathlib4::TruncatedWittVector.WittVector.TruncatedWittVector.WittVector.TruncatedWittVector.WittVector.TruncatedWittVector.card` | 0 | 0 | 0 | none |

## Availability

| Goal | Checked | Available | Failed | Target/alias | Aesop-safe available | Aesop-unsafe available | Simp-safe available | Simp-unsafe available |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| `mathlib4::TruncatedWittVector.WittVector.TruncatedWittVector.WittVector.TruncatedWittVector.WittVector.TruncatedWittVector.card` | 32 | 18 | 14 | 1 | 3 | 15 | 3 | 15 |

## Candidate Audit Summary

| Metric | Count |
|---|---:|
| `aesop_safe_fact_available` | 3 |
| `aesop_unsafe_fact_available` | 15 |
| `available` | 18 |
| `learned_candidate` | 32 |
| `proof_core` | 3 |
| `selected` | 32 |
| `simp_safe_available` | 3 |
| `simp_unsafe_available` | 15 |
| `target_or_alias` | 1 |
| `unavailable` | 14 |

### By Category

| Category | Count |
|---|---:|
| `definition_like` | 23 |
| `simp_attr` | 3 |
| `class` | 2 |
| `structure` | 2 |
| `theorem_like` | 2 |

### By Decl Kind

| Decl kind | Count |
|---|---:|
| `def` | 23 |
| `theorem` | 4 |
| `class` | 2 |
| `structure` | 2 |
| `lemma` | 1 |

## Readout

- No non-empty-premise proof was found; inspect action failures before scaling.

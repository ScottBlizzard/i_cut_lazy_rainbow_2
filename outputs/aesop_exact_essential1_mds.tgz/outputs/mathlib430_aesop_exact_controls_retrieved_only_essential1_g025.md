# Mathlib 4.30 Replayable-Subset Proof-Action Matrix

- Verdict: `no_nonempty_positive`
- Replay filter: `/workspace/thymic_project/paper/iclr_2/outputs/mathlib430_pretheorem_original_tactic_probe_490.json`
- Pool mode: `legacy`
- Candidate source: `retrieved_only`
- Result action suffix: `_retrieved_only_exact`
- Replayable goals evaluated: 1
- Attempts: 9
- Verified attempts: 0
- Non-empty-premise verified attempts: 0
- Goals with any proof: 0
- Goals with non-empty-premise proof: 0
- Action-dependent goals: 0

## Status Counts

| Status | Count |
|---|---:|
| `sorry_warning` | 9 |

## By Action

| Action | Verified | Non-empty verified | Attempts |
|---|---:|---:|---:|
| `aesop_core_plus_learned_countmatched_facts_retrieved_only_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_countmatched_simps_retrieved_only_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_facts_retrieved_only_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_identity_retrieved_only_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_random_split_retrieved_only_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_retrieved_only_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_simps_retrieved_only_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_swapped_retrieved_only_exact` | 0 | 0 | 1 |
| `aesop_empty_retrieved_only_exact` | 0 | 0 | 1 |

## By Goal

| Goal | Verified | Non-empty verified | Empty verified | Best |
|---|---:|---:|---:|---|
| `mathlib4::Finset.Fin.prod_Iio_castSucc` | 0 | 0 | 0 | none |

## Availability

| Goal | Checked | Available | Failed | Target/alias | Aesop-safe available | Aesop-unsafe available | Simp-safe available | Simp-unsafe available |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| `mathlib4::Finset.Fin.prod_Iio_castSucc` | 32 | 18 | 14 | 0 | 17 | 1 | 12 | 6 |

## Candidate Audit Summary

| Metric | Count |
|---|---:|
| `aesop_safe_fact_available` | 17 |
| `aesop_unsafe_fact_available` | 1 |
| `available` | 18 |
| `learned_candidate` | 32 |
| `proof_core` | 0 |
| `selected` | 32 |
| `simp_safe_available` | 12 |
| `simp_unsafe_available` | 6 |
| `target_or_alias` | 0 |
| `unavailable` | 14 |

### By Category

| Category | Count |
|---|---:|
| `simp_attr` | 16 |
| `theorem_like` | 13 |
| `definition_like` | 3 |

### By Decl Kind

| Decl kind | Count |
|---|---:|
| `theorem` | 20 |
| `lemma` | 8 |
| `def` | 4 |

## Readout

- No non-empty-premise proof was found; inspect action failures before scaling.

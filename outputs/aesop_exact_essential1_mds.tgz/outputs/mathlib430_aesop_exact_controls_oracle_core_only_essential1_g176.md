# Mathlib 4.30 Replayable-Subset Proof-Action Matrix

- Verdict: `pass_action_dependent`
- Replay filter: `/workspace/thymic_project/paper/iclr_2/outputs/mathlib430_pretheorem_original_tactic_probe_490.json`
- Pool mode: `legacy`
- Candidate source: `oracle_core_only`
- Result action suffix: `_oracle_core_only_exact`
- Replayable goals evaluated: 1
- Attempts: 9
- Verified attempts: 6
- Non-empty-premise verified attempts: 6
- Goals with any proof: 1
- Goals with non-empty-premise proof: 1
- Action-dependent goals: 1

## Status Counts

| Status | Count |
|---|---:|
| `proved` | 6 |
| `search_fail` | 3 |

## By Action

| Action | Verified | Non-empty verified | Attempts |
|---|---:|---:|---:|
| `aesop_core_plus_learned_countmatched_facts_oracle_core_only_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_countmatched_simps_oracle_core_only_exact` | 1 | 1 | 1 |
| `aesop_core_plus_learned_facts_oracle_core_only_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_identity_oracle_core_only_exact` | 1 | 1 | 1 |
| `aesop_core_plus_learned_oracle_core_only_exact` | 1 | 1 | 1 |
| `aesop_core_plus_learned_random_split_oracle_core_only_exact` | 1 | 1 | 1 |
| `aesop_core_plus_learned_simps_oracle_core_only_exact` | 1 | 1 | 1 |
| `aesop_core_plus_learned_swapped_oracle_core_only_exact` | 1 | 1 | 1 |
| `aesop_empty_oracle_core_only_exact` | 0 | 0 | 1 |

## By Goal

| Goal | Verified | Non-empty verified | Empty verified | Best |
|---|---:|---:|---:|---|
| `mathlib4::CategoryTheory.Limits.inr_zeroCoprodIso_hom` | 6 | 6 | 0 | `aesop_core_plus_learned_oracle_core_only_exact` (3 facts, 3 simps) |

## Availability

| Goal | Checked | Available | Failed | Target/alias | Aesop-safe available | Aesop-unsafe available | Simp-safe available | Simp-unsafe available |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| `mathlib4::CategoryTheory.Limits.inr_zeroCoprodIso_hom` | 3 | 3 | 0 | 0 | 0 | 3 | 1 | 2 |

## Candidate Audit Summary

| Metric | Count |
|---|---:|
| `aesop_safe_fact_available` | 0 |
| `aesop_unsafe_fact_available` | 3 |
| `available` | 3 |
| `learned_candidate` | 3 |
| `proof_core` | 3 |
| `selected` | 3 |
| `simp_safe_available` | 1 |
| `simp_unsafe_available` | 2 |
| `target_or_alias` | 0 |
| `unavailable` | 0 |

### By Category

| Category | Count |
|---|---:|
| `definition_like` | 3 |

### By Decl Kind

| Decl kind | Count |
|---|---:|
| `def` | 2 |
| `abbrev` | 1 |

## Readout

- This pilot found at least one action-dependent proof, so the proof-action routing route should be scaled.

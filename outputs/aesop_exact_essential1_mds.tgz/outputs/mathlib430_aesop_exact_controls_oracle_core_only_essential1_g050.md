# Mathlib 4.30 Replayable-Subset Proof-Action Matrix

- Verdict: `no_nonempty_positive`
- Replay filter: `/workspace/thymic_project/paper/iclr_2/outputs/mathlib430_pretheorem_original_tactic_probe_490.json`
- Pool mode: `legacy`
- Candidate source: `oracle_core_only`
- Result action suffix: `_oracle_core_only_exact`
- Replayable goals evaluated: 1
- Attempts: 9
- Verified attempts: 0
- Non-empty-premise verified attempts: 0
- Goals with any proof: 0
- Goals with non-empty-premise proof: 0
- Action-dependent goals: 0

## Status Counts

| Status | Count |
|---|---:|
| `search_fail` | 1 |
| `simp_fail` | 8 |

## By Action

| Action | Verified | Non-empty verified | Attempts |
|---|---:|---:|---:|
| `aesop_core_plus_learned_countmatched_facts_oracle_core_only_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_countmatched_simps_oracle_core_only_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_facts_oracle_core_only_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_identity_oracle_core_only_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_oracle_core_only_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_random_split_oracle_core_only_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_simps_oracle_core_only_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_swapped_oracle_core_only_exact` | 0 | 0 | 1 |
| `aesop_empty_oracle_core_only_exact` | 0 | 0 | 1 |

## By Goal

| Goal | Verified | Non-empty verified | Empty verified | Best |
|---|---:|---:|---:|---|
| `mathlib4::Polynomial.contentIdeal_le_span_content` | 0 | 0 | 0 | none |

## Availability

| Goal | Checked | Available | Failed | Target/alias | Aesop-safe available | Aesop-unsafe available | Simp-safe available | Simp-unsafe available |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| `mathlib4::Polynomial.contentIdeal_le_span_content` | 8 | 8 | 0 | 0 | 5 | 3 | 3 | 5 |

## Candidate Audit Summary

| Metric | Count |
|---|---:|
| `aesop_safe_fact_available` | 5 |
| `aesop_unsafe_fact_available` | 3 |
| `available` | 8 |
| `learned_candidate` | 6 |
| `proof_core` | 8 |
| `selected` | 8 |
| `simp_safe_available` | 3 |
| `simp_unsafe_available` | 5 |
| `target_or_alias` | 0 |
| `unavailable` | 0 |

### By Category

| Category | Count |
|---|---:|
| `theorem_like` | 4 |
| `proof_core_only_unknown` | 2 |
| `definition_like` | 1 |
| `simp_attr` | 1 |

### By Decl Kind

| Decl kind | Count |
|---|---:|
| `theorem` | 5 |
| `proof_core_only` | 2 |
| `abbrev` | 1 |

## Readout

- No non-empty-premise proof was found; inspect action failures before scaling.

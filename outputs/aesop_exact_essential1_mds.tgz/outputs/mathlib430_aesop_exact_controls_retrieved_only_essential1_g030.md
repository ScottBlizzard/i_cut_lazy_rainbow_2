# Mathlib 4.30 Replayable-Subset Proof-Action Matrix

- Verdict: `no_nonempty_positive`
- Replay filter: `/workspace/thymic_project/paper/iclr_2/outputs/mathlib430_pretheorem_original_tactic_probe_490.json`
- Pool mode: `legacy`
- Candidate source: `retrieved_only`
- Result action suffix: `_retrieved_only_exact`
- Replayable goals evaluated: 1
- Attempts: 9
- Verified attempts: 0
- Non-empty-premise verified attempts: 0
- Goals with any proof: 0
- Goals with non-empty-premise proof: 0
- Action-dependent goals: 0

## Status Counts

| Status | Count |
|---|---:|
| `lean_error` | 2 |
| `search_fail` | 5 |
| `simp_fail` | 2 |

## By Action

| Action | Verified | Non-empty verified | Attempts |
|---|---:|---:|---:|
| `aesop_core_plus_learned_countmatched_facts_retrieved_only_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_countmatched_simps_retrieved_only_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_facts_retrieved_only_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_identity_retrieved_only_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_random_split_retrieved_only_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_retrieved_only_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_simps_retrieved_only_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_swapped_retrieved_only_exact` | 0 | 0 | 1 |
| `aesop_empty_retrieved_only_exact` | 0 | 0 | 1 |

## By Goal

| Goal | Verified | Non-empty verified | Empty verified | Best |
|---|---:|---:|---:|---|
| `mathlib4::ContinuousMap.norm_smul_const` | 0 | 0 | 0 | none |

## Availability

| Goal | Checked | Available | Failed | Target/alias | Aesop-safe available | Aesop-unsafe available | Simp-safe available | Simp-unsafe available |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| `mathlib4::ContinuousMap.norm_smul_const` | 32 | 25 | 7 | 0 | 6 | 19 | 6 | 19 |

## Candidate Audit Summary

| Metric | Count |
|---|---:|
| `aesop_safe_fact_available` | 6 |
| `aesop_unsafe_fact_available` | 19 |
| `available` | 25 |
| `learned_candidate` | 32 |
| `proof_core` | 6 |
| `selected` | 32 |
| `simp_safe_available` | 6 |
| `simp_unsafe_available` | 19 |
| `target_or_alias` | 0 |
| `unavailable` | 7 |

### By Category

| Category | Count |
|---|---:|
| `definition_like` | 18 |
| `simp_attr` | 5 |
| `theorem_like` | 5 |
| `class` | 4 |

### By Decl Kind

| Decl kind | Count |
|---|---:|
| `abbrev` | 11 |
| `def` | 11 |
| `theorem` | 6 |
| `class` | 4 |

## Readout

- No non-empty-premise proof was found; inspect action failures before scaling.

# Mathlib 4.30 Replayable-Subset Proof-Action Matrix

- Verdict: `partial_nonempty_positive`
- Replay filter: `/workspace/thymic_project/paper/iclr_2/outputs/mathlib430_pretheorem_original_tactic_probe_490.json`
- Pool mode: `legacy`
- Candidate source: `oracle_core_only`
- Result action suffix: `_oracle_core_only_exact`
- Replayable goals evaluated: 1
- Attempts: 9
- Verified attempts: 9
- Non-empty-premise verified attempts: 8
- Goals with any proof: 1
- Goals with non-empty-premise proof: 1
- Action-dependent goals: 0

## Status Counts

| Status | Count |
|---|---:|
| `proved` | 9 |

## By Action

| Action | Verified | Non-empty verified | Attempts |
|---|---:|---:|---:|
| `aesop_core_plus_learned_countmatched_facts_oracle_core_only_exact` | 1 | 1 | 1 |
| `aesop_core_plus_learned_countmatched_simps_oracle_core_only_exact` | 1 | 1 | 1 |
| `aesop_core_plus_learned_facts_oracle_core_only_exact` | 1 | 1 | 1 |
| `aesop_core_plus_learned_identity_oracle_core_only_exact` | 1 | 1 | 1 |
| `aesop_core_plus_learned_oracle_core_only_exact` | 1 | 1 | 1 |
| `aesop_core_plus_learned_random_split_oracle_core_only_exact` | 1 | 1 | 1 |
| `aesop_core_plus_learned_simps_oracle_core_only_exact` | 1 | 1 | 1 |
| `aesop_core_plus_learned_swapped_oracle_core_only_exact` | 1 | 1 | 1 |
| `aesop_empty_oracle_core_only_exact` | 1 | 0 | 1 |

## By Goal

| Goal | Verified | Non-empty verified | Empty verified | Best |
|---|---:|---:|---:|---|
| `mathlib4::Rat.Nat.dist_cast_rat` | 9 | 8 | 1 | `aesop_empty_oracle_core_only_exact` (0 facts, 0 simps) |

## Availability

| Goal | Checked | Available | Failed | Target/alias | Aesop-safe available | Aesop-unsafe available | Simp-safe available | Simp-unsafe available |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| `mathlib4::Rat.Nat.dist_cast_rat` | 2 | 2 | 0 | 0 | 2 | 0 | 1 | 1 |

## Candidate Audit Summary

| Metric | Count |
|---|---:|
| `aesop_safe_fact_available` | 2 |
| `aesop_unsafe_fact_available` | 0 |
| `available` | 2 |
| `learned_candidate` | 2 |
| `proof_core` | 2 |
| `selected` | 2 |
| `simp_safe_available` | 1 |
| `simp_unsafe_available` | 1 |
| `target_or_alias` | 0 |
| `unavailable` | 0 |

### By Category

| Category | Count |
|---|---:|
| `theorem_like` | 2 |

### By Decl Kind

| Decl kind | Count |
|---|---:|
| `theorem` | 2 |

## Readout

- Non-empty-premise proofs exist, but empty baselines also solve those goals; scale cautiously and separate easy goals.

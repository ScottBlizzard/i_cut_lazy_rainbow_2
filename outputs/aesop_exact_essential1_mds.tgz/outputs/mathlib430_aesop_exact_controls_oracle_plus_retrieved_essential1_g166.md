# Mathlib 4.30 Replayable-Subset Proof-Action Matrix

- Verdict: `partial_nonempty_positive`
- Replay filter: `/workspace/thymic_project/paper/iclr_2/outputs/mathlib430_pretheorem_original_tactic_probe_490.json`
- Pool mode: `legacy`
- Candidate source: `oracle_plus_retrieved`
- Result action suffix: `_oracle_plus_retrieved_exact`
- Replayable goals evaluated: 1
- Attempts: 9
- Verified attempts: 9
- Non-empty-premise verified attempts: 8
- Goals with any proof: 1
- Goals with non-empty-premise proof: 1
- Action-dependent goals: 0

## Status Counts

| Status | Count |
|---|---:|
| `proved` | 9 |

## By Action

| Action | Verified | Non-empty verified | Attempts |
|---|---:|---:|---:|
| `aesop_core_plus_learned_countmatched_facts_oracle_plus_retrieved_exact` | 1 | 1 | 1 |
| `aesop_core_plus_learned_countmatched_simps_oracle_plus_retrieved_exact` | 1 | 1 | 1 |
| `aesop_core_plus_learned_facts_oracle_plus_retrieved_exact` | 1 | 1 | 1 |
| `aesop_core_plus_learned_identity_oracle_plus_retrieved_exact` | 1 | 1 | 1 |
| `aesop_core_plus_learned_oracle_plus_retrieved_exact` | 1 | 1 | 1 |
| `aesop_core_plus_learned_random_split_oracle_plus_retrieved_exact` | 1 | 1 | 1 |
| `aesop_core_plus_learned_simps_oracle_plus_retrieved_exact` | 1 | 1 | 1 |
| `aesop_core_plus_learned_swapped_oracle_plus_retrieved_exact` | 1 | 1 | 1 |
| `aesop_empty_oracle_plus_retrieved_exact` | 1 | 0 | 1 |

## By Goal

| Goal | Verified | Non-empty verified | Empty verified | Best |
|---|---:|---:|---:|---|
| `mathlib4::Finset.Fin.prod_Ioo_cast` | 9 | 8 | 1 | `aesop_empty_oracle_plus_retrieved_exact` (0 facts, 0 simps) |

## Availability

| Goal | Checked | Available | Failed | Target/alias | Aesop-safe available | Aesop-unsafe available | Simp-safe available | Simp-unsafe available |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| `mathlib4::Finset.Fin.prod_Ioo_cast` | 33 | 18 | 15 | 0 | 13 | 5 | 9 | 9 |

## Candidate Audit Summary

| Metric | Count |
|---|---:|
| `aesop_safe_fact_available` | 13 |
| `aesop_unsafe_fact_available` | 5 |
| `available` | 18 |
| `learned_candidate` | 32 |
| `proof_core` | 2 |
| `selected` | 33 |
| `simp_safe_available` | 9 |
| `simp_unsafe_available` | 9 |
| `target_or_alias` | 0 |
| `unavailable` | 15 |

### By Category

| Category | Count |
|---|---:|
| `simp_attr` | 12 |
| `definition_like` | 11 |
| `theorem_like` | 9 |
| `proof_core_only_unknown` | 1 |

### By Decl Kind

| Decl kind | Count |
|---|---:|
| `theorem` | 16 |
| `def` | 12 |
| `lemma` | 4 |
| `proof_core_only` | 1 |

## Readout

- Non-empty-premise proofs exist, but empty baselines also solve those goals; scale cautiously and separate easy goals.

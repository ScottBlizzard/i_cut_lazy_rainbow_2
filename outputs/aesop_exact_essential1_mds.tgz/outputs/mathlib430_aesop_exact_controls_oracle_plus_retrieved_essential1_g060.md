# Mathlib 4.30 Replayable-Subset Proof-Action Matrix

- Verdict: `no_nonempty_positive`
- Replay filter: `/workspace/thymic_project/paper/iclr_2/outputs/mathlib430_pretheorem_original_tactic_probe_490.json`
- Pool mode: `legacy`
- Candidate source: `oracle_plus_retrieved`
- Result action suffix: `_oracle_plus_retrieved_exact`
- Replayable goals evaluated: 1
- Attempts: 9
- Verified attempts: 0
- Non-empty-premise verified attempts: 0
- Goals with any proof: 0
- Goals with non-empty-premise proof: 0
- Action-dependent goals: 0

## Status Counts

| Status | Count |
|---|---:|
| `search_fail` | 2 |
| `simp_fail` | 7 |

## By Action

| Action | Verified | Non-empty verified | Attempts |
|---|---:|---:|---:|
| `aesop_core_plus_learned_countmatched_facts_oracle_plus_retrieved_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_countmatched_simps_oracle_plus_retrieved_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_facts_oracle_plus_retrieved_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_identity_oracle_plus_retrieved_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_oracle_plus_retrieved_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_random_split_oracle_plus_retrieved_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_simps_oracle_plus_retrieved_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_swapped_oracle_plus_retrieved_exact` | 0 | 0 | 1 |
| `aesop_empty_oracle_plus_retrieved_exact` | 0 | 0 | 1 |

## By Goal

| Goal | Verified | Non-empty verified | Empty verified | Best |
|---|---:|---:|---:|---|
| `mathlib4::DiscreteUniformity.eq_pure_of_cauchy` | 0 | 0 | 0 | none |

## Availability

| Goal | Checked | Available | Failed | Target/alias | Aesop-safe available | Aesop-unsafe available | Simp-safe available | Simp-unsafe available |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| `mathlib4::DiscreteUniformity.eq_pure_of_cauchy` | 34 | 20 | 14 | 0 | 16 | 4 | 4 | 16 |

## Candidate Audit Summary

| Metric | Count |
|---|---:|
| `aesop_safe_fact_available` | 16 |
| `aesop_unsafe_fact_available` | 4 |
| `available` | 20 |
| `learned_candidate` | 32 |
| `proof_core` | 5 |
| `selected` | 34 |
| `simp_safe_available` | 4 |
| `simp_unsafe_available` | 16 |
| `target_or_alias` | 0 |
| `unavailable` | 14 |

### By Category

| Category | Count |
|---|---:|
| `theorem_like` | 22 |
| `definition_like` | 5 |
| `simp_attr` | 4 |
| `proof_core_only_unknown` | 2 |
| `structure` | 1 |

### By Decl Kind

| Decl kind | Count |
|---|---:|
| `theorem` | 20 |
| `lemma` | 6 |
| `def` | 5 |
| `proof_core_only` | 2 |
| `structure` | 1 |

## Readout

- No non-empty-premise proof was found; inspect action failures before scaling.

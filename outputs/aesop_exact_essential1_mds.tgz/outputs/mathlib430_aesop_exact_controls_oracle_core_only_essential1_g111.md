# Mathlib 4.30 Replayable-Subset Proof-Action Matrix

- Verdict: `no_nonempty_positive`
- Replay filter: `/workspace/thymic_project/paper/iclr_2/outputs/mathlib430_pretheorem_original_tactic_probe_490.json`
- Pool mode: `legacy`
- Candidate source: `oracle_core_only`
- Result action suffix: `_oracle_core_only_exact`
- Replayable goals evaluated: 1
- Attempts: 9
- Verified attempts: 0
- Non-empty-premise verified attempts: 0
- Goals with any proof: 0
- Goals with non-empty-premise proof: 0
- Action-dependent goals: 0

## Status Counts

| Status | Count |
|---|---:|
| `lean_error` | 1 |
| `simp_fail` | 8 |

## By Action

| Action | Verified | Non-empty verified | Attempts |
|---|---:|---:|---:|
| `aesop_core_plus_learned_countmatched_facts_oracle_core_only_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_countmatched_simps_oracle_core_only_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_facts_oracle_core_only_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_identity_oracle_core_only_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_oracle_core_only_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_random_split_oracle_core_only_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_simps_oracle_core_only_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_swapped_oracle_core_only_exact` | 0 | 0 | 1 |
| `aesop_empty_oracle_core_only_exact` | 0 | 0 | 1 |

## By Goal

| Goal | Verified | Non-empty verified | Empty verified | Best |
|---|---:|---:|---:|---|
| `mathlib4::mem_rootsOfUnity_prime_pow_mul_iff` | 0 | 0 | 0 | none |

## Availability

| Goal | Checked | Available | Failed | Target/alias | Aesop-safe available | Aesop-unsafe available | Simp-safe available | Simp-unsafe available |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| `mathlib4::mem_rootsOfUnity_prime_pow_mul_iff` | 3 | 3 | 0 | 0 | 1 | 2 | 1 | 2 |

## Candidate Audit Summary

| Metric | Count |
|---|---:|
| `aesop_safe_fact_available` | 1 |
| `aesop_unsafe_fact_available` | 2 |
| `available` | 3 |
| `learned_candidate` | 2 |
| `proof_core` | 3 |
| `selected` | 3 |
| `simp_safe_available` | 1 |
| `simp_unsafe_available` | 2 |
| `target_or_alias` | 0 |
| `unavailable` | 0 |

### By Category

| Category | Count |
|---|---:|
| `definition_like` | 1 |
| `proof_core_only_unknown` | 1 |
| `theorem_like` | 1 |

### By Decl Kind

| Decl kind | Count |
|---|---:|
| `def` | 1 |
| `proof_core_only` | 1 |
| `theorem` | 1 |

## Readout

- No non-empty-premise proof was found; inspect action failures before scaling.

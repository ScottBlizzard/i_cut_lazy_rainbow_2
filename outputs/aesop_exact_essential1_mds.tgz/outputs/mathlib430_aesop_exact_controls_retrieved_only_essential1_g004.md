# Mathlib 4.30 Replayable-Subset Proof-Action Matrix

- Verdict: `no_nonempty_positive`
- Replay filter: `/workspace/thymic_project/paper/iclr_2/outputs/mathlib430_pretheorem_original_tactic_probe_490.json`
- Pool mode: `legacy`
- Candidate source: `retrieved_only`
- Result action suffix: `_retrieved_only_exact`
- Replayable goals evaluated: 1
- Attempts: 9
- Verified attempts: 0
- Non-empty-premise verified attempts: 0
- Goals with any proof: 0
- Goals with non-empty-premise proof: 0
- Action-dependent goals: 0

## Status Counts

| Status | Count |
|---|---:|
| `lean_error` | 1 |
| `simp_fail` | 6 |
| `timeout` | 2 |

## By Action

| Action | Verified | Non-empty verified | Attempts |
|---|---:|---:|---:|
| `aesop_core_plus_learned_countmatched_facts_retrieved_only_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_countmatched_simps_retrieved_only_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_facts_retrieved_only_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_identity_retrieved_only_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_random_split_retrieved_only_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_retrieved_only_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_simps_retrieved_only_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_swapped_retrieved_only_exact` | 0 | 0 | 1 |
| `aesop_empty_retrieved_only_exact` | 0 | 0 | 1 |

## By Goal

| Goal | Verified | Non-empty verified | Empty verified | Best |
|---|---:|---:|---:|---|
| `mathlib4::Set.Intersecting.insert` | 0 | 0 | 0 | none |

## Availability

| Goal | Checked | Available | Failed | Target/alias | Aesop-safe available | Aesop-unsafe available | Simp-safe available | Simp-unsafe available |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| `mathlib4::Set.Intersecting.insert` | 32 | 16 | 16 | 0 | 13 | 3 | 3 | 13 |

## Candidate Audit Summary

| Metric | Count |
|---|---:|
| `aesop_safe_fact_available` | 13 |
| `aesop_unsafe_fact_available` | 3 |
| `available` | 16 |
| `learned_candidate` | 32 |
| `proof_core` | 3 |
| `selected` | 32 |
| `simp_safe_available` | 3 |
| `simp_unsafe_available` | 13 |
| `target_or_alias` | 0 |
| `unavailable` | 16 |

### By Category

| Category | Count |
|---|---:|
| `theorem_like` | 19 |
| `simp_attr` | 7 |
| `definition_like` | 6 |

### By Decl Kind

| Decl kind | Count |
|---|---:|
| `theorem` | 24 |
| `def` | 6 |
| `lemma` | 2 |

## Readout

- No non-empty-premise proof was found; inspect action failures before scaling.

# Mathlib 4.30 Replayable-Subset Proof-Action Matrix

- Verdict: `pass_action_dependent`
- Replay filter: `/workspace/thymic_project/paper/iclr_2/outputs/mathlib430_pretheorem_original_tactic_probe_490.json`
- Pool mode: `legacy`
- Candidate source: `retrieved_only`
- Result action suffix: `_retrieved_only_exact`
- Replayable goals evaluated: 1
- Attempts: 9
- Verified attempts: 5
- Non-empty-premise verified attempts: 5
- Goals with any proof: 1
- Goals with non-empty-premise proof: 1
- Action-dependent goals: 1

## Status Counts

| Status | Count |
|---|---:|
| `lean_error` | 1 |
| `proved` | 5 |
| `simp_fail` | 3 |

## By Action

| Action | Verified | Non-empty verified | Attempts |
|---|---:|---:|---:|
| `aesop_core_plus_learned_countmatched_facts_retrieved_only_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_countmatched_simps_retrieved_only_exact` | 1 | 1 | 1 |
| `aesop_core_plus_learned_facts_retrieved_only_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_identity_retrieved_only_exact` | 1 | 1 | 1 |
| `aesop_core_plus_learned_random_split_retrieved_only_exact` | 1 | 1 | 1 |
| `aesop_core_plus_learned_retrieved_only_exact` | 1 | 1 | 1 |
| `aesop_core_plus_learned_simps_retrieved_only_exact` | 1 | 1 | 1 |
| `aesop_core_plus_learned_swapped_retrieved_only_exact` | 0 | 0 | 1 |
| `aesop_empty_retrieved_only_exact` | 0 | 0 | 1 |

## By Goal

| Goal | Verified | Non-empty verified | Empty verified | Best |
|---|---:|---:|---:|---|
| `mathlib4::mem_balancedCore_iff` | 5 | 5 | 0 | `aesop_core_plus_learned_retrieved_only_exact` (6 facts, 7 simps) |

## Availability

| Goal | Checked | Available | Failed | Target/alias | Aesop-safe available | Aesop-unsafe available | Simp-safe available | Simp-unsafe available |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| `mathlib4::mem_balancedCore_iff` | 32 | 10 | 22 | 0 | 6 | 4 | 4 | 6 |

## Candidate Audit Summary

| Metric | Count |
|---|---:|
| `aesop_safe_fact_available` | 6 |
| `aesop_unsafe_fact_available` | 4 |
| `available` | 10 |
| `learned_candidate` | 32 |
| `proof_core` | 4 |
| `selected` | 32 |
| `simp_safe_available` | 4 |
| `simp_unsafe_available` | 6 |
| `target_or_alias` | 0 |
| `unavailable` | 22 |

### By Category

| Category | Count |
|---|---:|
| `theorem_like` | 24 |
| `definition_like` | 4 |
| `simp_attr` | 4 |

### By Decl Kind

| Decl kind | Count |
|---|---:|
| `theorem` | 27 |
| `def` | 4 |
| `lemma` | 1 |

## Readout

- This pilot found at least one action-dependent proof, so the proof-action routing route should be scaled.

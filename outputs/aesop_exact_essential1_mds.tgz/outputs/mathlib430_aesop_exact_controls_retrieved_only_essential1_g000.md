# Mathlib 4.30 Replayable-Subset Proof-Action Matrix

- Verdict: `partial_nonempty_positive`
- Replay filter: `/workspace/thymic_project/paper/iclr_2/outputs/mathlib430_pretheorem_original_tactic_probe_490.json`
- Pool mode: `legacy`
- Candidate source: `retrieved_only`
- Result action suffix: `_retrieved_only_exact`
- Replayable goals evaluated: 1
- Attempts: 9
- Verified attempts: 5
- Non-empty-premise verified attempts: 4
- Goals with any proof: 1
- Goals with non-empty-premise proof: 1
- Action-dependent goals: 0

## Status Counts

| Status | Count |
|---|---:|
| `lean_error` | 2 |
| `proved` | 5 |
| `simp_fail` | 2 |

## By Action

| Action | Verified | Non-empty verified | Attempts |
|---|---:|---:|---:|
| `aesop_core_plus_learned_countmatched_facts_retrieved_only_exact` | 1 | 1 | 1 |
| `aesop_core_plus_learned_countmatched_simps_retrieved_only_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_facts_retrieved_only_exact` | 1 | 1 | 1 |
| `aesop_core_plus_learned_identity_retrieved_only_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_random_split_retrieved_only_exact` | 1 | 1 | 1 |
| `aesop_core_plus_learned_retrieved_only_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_simps_retrieved_only_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_swapped_retrieved_only_exact` | 1 | 1 | 1 |
| `aesop_empty_retrieved_only_exact` | 1 | 0 | 1 |

## By Goal

| Goal | Verified | Non-empty verified | Empty verified | Best |
|---|---:|---:|---:|---|
| `mathlib4::Module.rank_tensorProduct'` | 5 | 4 | 1 | `aesop_empty_retrieved_only_exact` (0 facts, 0 simps) |

## Availability

| Goal | Checked | Available | Failed | Target/alias | Aesop-safe available | Aesop-unsafe available | Simp-safe available | Simp-unsafe available |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| `mathlib4::Module.rank_tensorProduct'` | 32 | 22 | 10 | 0 | 21 | 1 | 9 | 13 |

## Candidate Audit Summary

| Metric | Count |
|---|---:|
| `aesop_safe_fact_available` | 21 |
| `aesop_unsafe_fact_available` | 1 |
| `available` | 22 |
| `learned_candidate` | 32 |
| `proof_core` | 1 |
| `selected` | 32 |
| `simp_safe_available` | 9 |
| `simp_unsafe_available` | 13 |
| `target_or_alias` | 0 |
| `unavailable` | 10 |

### By Category

| Category | Count |
|---|---:|
| `theorem_like` | 19 |
| `simp_attr` | 10 |
| `definition_like` | 2 |
| `unknown` | 1 |

### By Decl Kind

| Decl kind | Count |
|---|---:|
| `theorem` | 29 |
| `abbrev` | 1 |
| `def` | 1 |
| `unknown` | 1 |

## Readout

- Non-empty-premise proofs exist, but empty baselines also solve those goals; scale cautiously and separate easy goals.

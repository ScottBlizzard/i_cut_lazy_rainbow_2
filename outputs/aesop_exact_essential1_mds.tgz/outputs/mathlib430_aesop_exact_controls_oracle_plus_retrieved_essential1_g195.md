# Mathlib 4.30 Replayable-Subset Proof-Action Matrix

- Verdict: `pass_action_dependent`
- Replay filter: `/workspace/thymic_project/paper/iclr_2/outputs/mathlib430_pretheorem_original_tactic_probe_490.json`
- Pool mode: `legacy`
- Candidate source: `oracle_plus_retrieved`
- Result action suffix: `_oracle_plus_retrieved_exact`
- Replayable goals evaluated: 1
- Attempts: 9
- Verified attempts: 5
- Non-empty-premise verified attempts: 5
- Goals with any proof: 1
- Goals with non-empty-premise proof: 1
- Action-dependent goals: 1

## Status Counts

| Status | Count |
|---|---:|
| `lean_error` | 1 |
| `proved` | 5 |
| `simp_fail` | 3 |

## By Action

| Action | Verified | Non-empty verified | Attempts |
|---|---:|---:|---:|
| `aesop_core_plus_learned_countmatched_facts_oracle_plus_retrieved_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_countmatched_simps_oracle_plus_retrieved_exact` | 1 | 1 | 1 |
| `aesop_core_plus_learned_facts_oracle_plus_retrieved_exact` | 0 | 0 | 1 |
| `aesop_core_plus_learned_identity_oracle_plus_retrieved_exact` | 1 | 1 | 1 |
| `aesop_core_plus_learned_oracle_plus_retrieved_exact` | 1 | 1 | 1 |
| `aesop_core_plus_learned_random_split_oracle_plus_retrieved_exact` | 1 | 1 | 1 |
| `aesop_core_plus_learned_simps_oracle_plus_retrieved_exact` | 1 | 1 | 1 |
| `aesop_core_plus_learned_swapped_oracle_plus_retrieved_exact` | 0 | 0 | 1 |
| `aesop_empty_oracle_plus_retrieved_exact` | 0 | 0 | 1 |

## By Goal

| Goal | Verified | Non-empty verified | Empty verified | Best |
|---|---:|---:|---:|---|
| `mathlib4::WeierstrassCurve.j_eq_zero_iff'` | 5 | 5 | 0 | `aesop_core_plus_learned_oracle_plus_retrieved_exact` (9 facts, 9 simps) |

## Availability

| Goal | Checked | Available | Failed | Target/alias | Aesop-safe available | Aesop-unsafe available | Simp-safe available | Simp-unsafe available |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| `mathlib4::WeierstrassCurve.j_eq_zero_iff'` | 33 | 20 | 13 | 0 | 9 | 11 | 7 | 13 |

## Candidate Audit Summary

| Metric | Count |
|---|---:|
| `aesop_safe_fact_available` | 9 |
| `aesop_unsafe_fact_available` | 11 |
| `available` | 20 |
| `learned_candidate` | 32 |
| `proof_core` | 1 |
| `selected` | 33 |
| `simp_safe_available` | 7 |
| `simp_unsafe_available` | 13 |
| `target_or_alias` | 0 |
| `unavailable` | 13 |

### By Category

| Category | Count |
|---|---:|
| `simp_attr` | 11 |
| `definition_like` | 9 |
| `theorem_like` | 8 |
| `class` | 3 |
| `proof_core_only_unknown` | 1 |
| `structure` | 1 |

### By Decl Kind

| Decl kind | Count |
|---|---:|
| `lemma` | 16 |
| `def` | 10 |
| `class` | 3 |
| `theorem` | 2 |
| `proof_core_only` | 1 |
| `structure` | 1 |

## Readout

- This pilot found at least one action-dependent proof, so the proof-action routing route should be scaled.

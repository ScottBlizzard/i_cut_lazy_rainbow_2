# Mathlib 4.30 Replayable-Subset Proof-Action Matrix

- Verdict: `partial_nonempty_positive`
- Replay filter: `/workspace/thymic_project/paper/iclr_2/outputs/mathlib430_pretheorem_original_tactic_probe_fold1_500.json`
- Pool mode: `legacy`
- Candidate source: `retrieved_only`
- Replayable goals evaluated: 1
- Attempts: 10
- Verified attempts: 9
- Non-empty-premise verified attempts: 7
- Goals with any proof: 1
- Goals with non-empty-premise proof: 1
- Action-dependent goals: 0

## Status Counts

| Status | Count |
|---|---:|
| `lean_error` | 1 |
| `proved` | 9 |

## By Action

| Action | Verified | Non-empty verified | Attempts |
|---|---:|---:|---:|
| `aesop_core` | 1 | 0 | 1 |
| `aesop_core_plus_learned` | 1 | 1 | 1 |
| `aesop_core_plus_learned16` | 1 | 1 | 1 |
| `aesop_core_plus_learned32` | 1 | 1 | 1 |
| `aesop_core_plus_learned_swapped` | 1 | 1 | 1 |
| `aesop_learned16` | 1 | 1 | 1 |
| `aesop_learned32` | 1 | 1 | 1 |
| `aesop_learned8` | 1 | 1 | 1 |
| `hammerCore_core_plus_learned` | 0 | 0 | 1 |
| `hammer_empty` | 1 | 0 | 1 |

## By Goal

| Goal | Verified | Non-empty verified | Empty verified | Best |
|---|---:|---:|---:|---|
| `mathlib4::Set.Ioo_inter_Ioc_of_right_lt` | 9 | 7 | 2 | `hammer_empty` (0 facts, 0 simps) |

## Availability

| Goal | Checked | Available | Failed | Target/alias | Aesop-safe available | Aesop-unsafe available | Simp-safe available | Simp-unsafe available |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| `mathlib4::Set.Ioo_inter_Ioc_of_right_lt` | 32 | 23 | 9 | 0 | 21 | 2 | 8 | 15 |

## Candidate Audit Summary

| Metric | Count |
|---|---:|
| `aesop_safe_fact_available` | 21 |
| `aesop_unsafe_fact_available` | 2 |
| `available` | 23 |
| `learned_candidate` | 32 |
| `proof_core` | 2 |
| `selected` | 32 |
| `simp_safe_available` | 8 |
| `simp_unsafe_available` | 15 |
| `target_or_alias` | 0 |
| `unavailable` | 9 |

### By Category

| Category | Count |
|---|---:|
| `simp_attr` | 15 |
| `theorem_like` | 15 |
| `definition_like` | 2 |

### By Decl Kind

| Decl kind | Count |
|---|---:|
| `theorem` | 29 |
| `def` | 2 |
| `lemma` | 1 |

## Readout

- Non-empty-premise proofs exist, but empty baselines also solve those goals; scale cautiously and separate easy goals.

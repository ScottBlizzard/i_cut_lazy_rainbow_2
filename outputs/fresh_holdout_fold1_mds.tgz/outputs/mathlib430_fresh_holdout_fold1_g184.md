# Mathlib 4.30 Replayable-Subset Proof-Action Matrix

- Verdict: `pass_action_dependent`
- Replay filter: `/workspace/thymic_project/paper/iclr_2/outputs/mathlib430_pretheorem_original_tactic_probe_fold1_500.json`
- Pool mode: `legacy`
- Candidate source: `retrieved_only`
- Replayable goals evaluated: 1
- Attempts: 10
- Verified attempts: 6
- Non-empty-premise verified attempts: 6
- Goals with any proof: 1
- Goals with non-empty-premise proof: 1
- Action-dependent goals: 1

## Status Counts

| Status | Count |
|---|---:|
| `proved` | 6 |
| `search_fail` | 4 |

## By Action

| Action | Verified | Non-empty verified | Attempts |
|---|---:|---:|---:|
| `aesop_core` | 0 | 0 | 1 |
| `aesop_core_plus_learned` | 1 | 1 | 1 |
| `aesop_core_plus_learned16` | 1 | 1 | 1 |
| `aesop_core_plus_learned32` | 1 | 1 | 1 |
| `aesop_core_plus_learned_swapped` | 0 | 0 | 1 |
| `aesop_learned16` | 1 | 1 | 1 |
| `aesop_learned32` | 1 | 1 | 1 |
| `aesop_learned8` | 1 | 1 | 1 |
| `hammerCore_core_plus_learned` | 0 | 0 | 1 |
| `hammer_empty` | 0 | 0 | 1 |

## By Goal

| Goal | Verified | Non-empty verified | Empty verified | Best |
|---|---:|---:|---:|---|
| `mathlib4::MeasureTheory.weightedSMul_nonneg` | 6 | 6 | 0 | `aesop_core_plus_learned` (8 facts, 8 simps) |

## Availability

| Goal | Checked | Available | Failed | Target/alias | Aesop-safe available | Aesop-unsafe available | Simp-safe available | Simp-unsafe available |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| `mathlib4::MeasureTheory.weightedSMul_nonneg` | 32 | 16 | 16 | 0 | 12 | 4 | 4 | 12 |

## Candidate Audit Summary

| Metric | Count |
|---|---:|
| `aesop_safe_fact_available` | 12 |
| `aesop_unsafe_fact_available` | 4 |
| `available` | 16 |
| `learned_candidate` | 32 |
| `proof_core` | 7 |
| `selected` | 32 |
| `simp_safe_available` | 4 |
| `simp_unsafe_available` | 12 |
| `target_or_alias` | 0 |
| `unavailable` | 16 |

### By Category

| Category | Count |
|---|---:|
| `theorem_like` | 17 |
| `definition_like` | 7 |
| `simp_attr` | 4 |
| `class` | 2 |
| `structure` | 2 |

### By Decl Kind

| Decl kind | Count |
|---|---:|
| `theorem` | 17 |
| `def` | 7 |
| `lemma` | 4 |
| `class` | 2 |
| `structure` | 2 |

## Readout

- This pilot found at least one action-dependent proof, so the proof-action routing route should be scaled.

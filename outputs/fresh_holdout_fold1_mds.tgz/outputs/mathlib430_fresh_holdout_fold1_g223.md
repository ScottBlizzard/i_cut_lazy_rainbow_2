# Mathlib 4.30 Replayable-Subset Proof-Action Matrix

- Verdict: `pass_action_dependent`
- Replay filter: `/workspace/thymic_project/paper/iclr_2/outputs/mathlib430_pretheorem_original_tactic_probe_fold1_500.json`
- Pool mode: `legacy`
- Candidate source: `retrieved_only`
- Replayable goals evaluated: 1
- Attempts: 10
- Verified attempts: 6
- Non-empty-premise verified attempts: 6
- Goals with any proof: 1
- Goals with non-empty-premise proof: 1
- Action-dependent goals: 1

## Status Counts

| Status | Count |
|---|---:|
| `lean_error` | 1 |
| `proved` | 6 |
| `search_fail` | 3 |

## By Action

| Action | Verified | Non-empty verified | Attempts |
|---|---:|---:|---:|
| `aesop_core` | 0 | 0 | 1 |
| `aesop_core_plus_learned` | 1 | 1 | 1 |
| `aesop_core_plus_learned16` | 1 | 1 | 1 |
| `aesop_core_plus_learned32` | 1 | 1 | 1 |
| `aesop_core_plus_learned_swapped` | 0 | 0 | 1 |
| `aesop_learned16` | 1 | 1 | 1 |
| `aesop_learned32` | 1 | 1 | 1 |
| `aesop_learned8` | 1 | 1 | 1 |
| `hammerCore_core_plus_learned` | 0 | 0 | 1 |
| `hammer_empty` | 0 | 0 | 1 |

## By Goal

| Goal | Verified | Non-empty verified | Empty verified | Best |
|---|---:|---:|---:|---|
| `mathlib4::IsBaseChange.linearMapLeftRightHom_toMatrix` | 6 | 6 | 0 | `aesop_core_plus_learned` (8 facts, 8 simps) |

## Availability

| Goal | Checked | Available | Failed | Target/alias | Aesop-safe available | Aesop-unsafe available | Simp-safe available | Simp-unsafe available |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| `mathlib4::IsBaseChange.linearMapLeftRightHom_toMatrix` | 32 | 21 | 11 | 0 | 13 | 8 | 6 | 15 |

## Candidate Audit Summary

| Metric | Count |
|---|---:|
| `aesop_safe_fact_available` | 13 |
| `aesop_unsafe_fact_available` | 8 |
| `available` | 21 |
| `learned_candidate` | 32 |
| `proof_core` | 8 |
| `selected` | 32 |
| `simp_safe_available` | 6 |
| `simp_unsafe_available` | 15 |
| `target_or_alias` | 0 |
| `unavailable` | 11 |

### By Category

| Category | Count |
|---|---:|
| `simp_attr` | 12 |
| `theorem_like` | 12 |
| `definition_like` | 8 |

### By Decl Kind

| Decl kind | Count |
|---|---:|
| `theorem` | 21 |
| `def` | 8 |
| `lemma` | 2 |
| `abbrev` | 1 |

## Readout

- This pilot found at least one action-dependent proof, so the proof-action routing route should be scaled.

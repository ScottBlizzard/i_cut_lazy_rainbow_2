# Mathlib 4.30 Replayable-Subset Proof-Action Matrix

- Verdict: `pass_action_dependent`
- Replay filter: `/workspace/thymic_project/paper/iclr_2/outputs/mathlib430_pretheorem_original_tactic_probe_fold1_500.json`
- Pool mode: `legacy`
- Candidate source: `retrieved_only`
- Replayable goals evaluated: 1
- Attempts: 10
- Verified attempts: 1
- Non-empty-premise verified attempts: 1
- Goals with any proof: 1
- Goals with non-empty-premise proof: 1
- Action-dependent goals: 1

## Status Counts

| Status | Count |
|---|---:|
| `proved` | 1 |
| `sorry_warning` | 9 |

## By Action

| Action | Verified | Non-empty verified | Attempts |
|---|---:|---:|---:|
| `aesop_core` | 0 | 0 | 1 |
| `aesop_core_plus_learned` | 0 | 0 | 1 |
| `aesop_core_plus_learned16` | 0 | 0 | 1 |
| `aesop_core_plus_learned32` | 0 | 0 | 1 |
| `aesop_core_plus_learned_swapped` | 1 | 1 | 1 |
| `aesop_learned16` | 0 | 0 | 1 |
| `aesop_learned32` | 0 | 0 | 1 |
| `aesop_learned8` | 0 | 0 | 1 |
| `hammerCore_core_plus_learned` | 0 | 0 | 1 |
| `hammer_empty` | 0 | 0 | 1 |

## By Goal

| Goal | Verified | Non-empty verified | Empty verified | Best |
|---|---:|---:|---:|---|
| `mathlib4::Finset.mul_prod_Ioo_eq_prod_Ico` | 1 | 1 | 0 | `aesop_core_plus_learned_swapped` (5 facts, 8 simps) |

## Availability

| Goal | Checked | Available | Failed | Target/alias | Aesop-safe available | Aesop-unsafe available | Simp-safe available | Simp-unsafe available |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| `mathlib4::Finset.mul_prod_Ioo_eq_prod_Ico` | 32 | 14 | 18 | 0 | 12 | 2 | 4 | 10 |

## Candidate Audit Summary

| Metric | Count |
|---|---:|
| `aesop_safe_fact_available` | 12 |
| `aesop_unsafe_fact_available` | 2 |
| `available` | 14 |
| `learned_candidate` | 32 |
| `proof_core` | 4 |
| `selected` | 32 |
| `simp_safe_available` | 4 |
| `simp_unsafe_available` | 10 |
| `target_or_alias` | 0 |
| `unavailable` | 18 |

### By Category

| Category | Count |
|---|---:|
| `theorem_like` | 24 |
| `simp_attr` | 6 |
| `definition_like` | 2 |

### By Decl Kind

| Decl kind | Count |
|---|---:|
| `theorem` | 25 |
| `lemma` | 5 |
| `def` | 2 |

## Readout

- This pilot found at least one action-dependent proof, so the proof-action routing route should be scaled.

# Mathlib 4.30 Replayable-Subset Proof-Action Matrix

- Verdict: `no_nonempty_positive`
- Replay filter: `/workspace/thymic_project/paper/iclr_2/outputs/mathlib430_pretheorem_original_tactic_probe_fold1_500.json`
- Pool mode: `legacy`
- Candidate source: `retrieved_only`
- Replayable goals evaluated: 1
- Attempts: 10
- Verified attempts: 0
- Non-empty-premise verified attempts: 0
- Goals with any proof: 0
- Goals with non-empty-premise proof: 0
- Action-dependent goals: 0

## Status Counts

| Status | Count |
|---|---:|
| `lean_error` | 1 |
| `search_fail` | 1 |
| `simp_fail` | 4 |
| `timeout` | 4 |

## By Action

| Action | Verified | Non-empty verified | Attempts |
|---|---:|---:|---:|
| `aesop_core` | 0 | 0 | 1 |
| `aesop_core_plus_learned` | 0 | 0 | 1 |
| `aesop_core_plus_learned16` | 0 | 0 | 1 |
| `aesop_core_plus_learned32` | 0 | 0 | 1 |
| `aesop_core_plus_learned_swapped` | 0 | 0 | 1 |
| `aesop_learned16` | 0 | 0 | 1 |
| `aesop_learned32` | 0 | 0 | 1 |
| `aesop_learned8` | 0 | 0 | 1 |
| `hammerCore_core_plus_learned` | 0 | 0 | 1 |
| `hammer_empty` | 0 | 0 | 1 |

## By Goal

| Goal | Verified | Non-empty verified | Empty verified | Best |
|---|---:|---:|---:|---|
| `mathlib4::WeierstrassCurve.Projective.negDblY_of_Z_ne_zero` | 0 | 0 | 0 | none |

## Availability

| Goal | Checked | Available | Failed | Target/alias | Aesop-safe available | Aesop-unsafe available | Simp-safe available | Simp-unsafe available |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| `mathlib4::WeierstrassCurve.Projective.negDblY_of_Z_ne_zero` | 32 | 15 | 17 | 0 | 13 | 2 | 2 | 13 |

## Candidate Audit Summary

| Metric | Count |
|---|---:|
| `aesop_safe_fact_available` | 13 |
| `aesop_unsafe_fact_available` | 2 |
| `available` | 15 |
| `learned_candidate` | 32 |
| `proof_core` | 1 |
| `selected` | 32 |
| `simp_safe_available` | 2 |
| `simp_unsafe_available` | 13 |
| `target_or_alias` | 0 |
| `unavailable` | 17 |

### By Category

| Category | Count |
|---|---:|
| `theorem_like` | 23 |
| `simp_attr` | 5 |
| `definition_like` | 4 |

### By Decl Kind

| Decl kind | Count |
|---|---:|
| `lemma` | 26 |
| `def` | 4 |
| `theorem` | 2 |

## Readout

- No non-empty-premise proof was found; inspect action failures before scaling.

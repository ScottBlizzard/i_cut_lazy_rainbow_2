# Mathlib 4.30 Replayable-Subset Proof-Action Matrix

- Verdict: `pass_action_dependent`
- Replay filter: `/workspace/thymic_project/paper/iclr_2/outputs/mathlib430_pretheorem_original_tactic_probe_fold1_500.json`
- Pool mode: `legacy`
- Candidate source: `retrieved_only`
- Replayable goals evaluated: 1
- Attempts: 10
- Verified attempts: 6
- Non-empty-premise verified attempts: 6
- Goals with any proof: 1
- Goals with non-empty-premise proof: 1
- Action-dependent goals: 1

## Status Counts

| Status | Count |
|---|---:|
| `lean_error` | 2 |
| `proved` | 6 |
| `search_fail` | 1 |
| `simp_fail` | 1 |

## By Action

| Action | Verified | Non-empty verified | Attempts |
|---|---:|---:|---:|
| `aesop_core` | 0 | 0 | 1 |
| `aesop_core_plus_learned` | 1 | 1 | 1 |
| `aesop_core_plus_learned16` | 1 | 1 | 1 |
| `aesop_core_plus_learned32` | 1 | 1 | 1 |
| `aesop_core_plus_learned_swapped` | 0 | 0 | 1 |
| `aesop_learned16` | 1 | 1 | 1 |
| `aesop_learned32` | 1 | 1 | 1 |
| `aesop_learned8` | 1 | 1 | 1 |
| `hammerCore_core_plus_learned` | 0 | 0 | 1 |
| `hammer_empty` | 0 | 0 | 1 |

## By Goal

| Goal | Verified | Non-empty verified | Empty verified | Best |
|---|---:|---:|---:|---|
| `mathlib4::Polynomial.Monic.ne_zero` | 6 | 6 | 0 | `aesop_core_plus_learned` (8 facts, 8 simps) |

## Availability

| Goal | Checked | Available | Failed | Target/alias | Aesop-safe available | Aesop-unsafe available | Simp-safe available | Simp-unsafe available |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| `mathlib4::Polynomial.Monic.ne_zero` | 32 | 26 | 6 | 0 | 23 | 3 | 15 | 11 |

## Candidate Audit Summary

| Metric | Count |
|---|---:|
| `aesop_safe_fact_available` | 23 |
| `aesop_unsafe_fact_available` | 3 |
| `available` | 26 |
| `learned_candidate` | 32 |
| `proof_core` | 2 |
| `selected` | 32 |
| `simp_safe_available` | 15 |
| `simp_unsafe_available` | 11 |
| `target_or_alias` | 0 |
| `unavailable` | 6 |

### By Category

| Category | Count |
|---|---:|
| `simp_attr` | 18 |
| `theorem_like` | 11 |
| `definition_like` | 2 |
| `class` | 1 |

### By Decl Kind

| Decl kind | Count |
|---|---:|
| `theorem` | 29 |
| `def` | 2 |
| `class` | 1 |

## Readout

- This pilot found at least one action-dependent proof, so the proof-action routing route should be scaled.

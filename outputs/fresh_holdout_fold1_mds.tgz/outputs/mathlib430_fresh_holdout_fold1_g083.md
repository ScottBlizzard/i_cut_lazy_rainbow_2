# Mathlib 4.30 Replayable-Subset Proof-Action Matrix

- Verdict: `no_nonempty_positive`
- Replay filter: `/workspace/thymic_project/paper/iclr_2/outputs/mathlib430_pretheorem_original_tactic_probe_fold1_500.json`
- Pool mode: `legacy`
- Candidate source: `retrieved_only`
- Replayable goals evaluated: 1
- Attempts: 10
- Verified attempts: 0
- Non-empty-premise verified attempts: 0
- Goals with any proof: 0
- Goals with non-empty-premise proof: 0
- Action-dependent goals: 0

## Status Counts

| Status | Count |
|---|---:|
| `lean_error` | 6 |
| `search_fail` | 3 |
| `timeout` | 1 |

## By Action

| Action | Verified | Non-empty verified | Attempts |
|---|---:|---:|---:|
| `aesop_core` | 0 | 0 | 1 |
| `aesop_core_plus_learned` | 0 | 0 | 1 |
| `aesop_core_plus_learned16` | 0 | 0 | 1 |
| `aesop_core_plus_learned32` | 0 | 0 | 1 |
| `aesop_core_plus_learned_swapped` | 0 | 0 | 1 |
| `aesop_learned16` | 0 | 0 | 1 |
| `aesop_learned32` | 0 | 0 | 1 |
| `aesop_learned8` | 0 | 0 | 1 |
| `hammerCore_core_plus_learned` | 0 | 0 | 1 |
| `hammer_empty` | 0 | 0 | 1 |

## By Goal

| Goal | Verified | Non-empty verified | Empty verified | Best |
|---|---:|---:|---:|---|
| `mathlib4::SSet.Truncated.Path.ext'` | 0 | 0 | 0 | none |

## Availability

| Goal | Checked | Available | Failed | Target/alias | Aesop-safe available | Aesop-unsafe available | Simp-safe available | Simp-unsafe available |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| `mathlib4::SSet.Truncated.Path.ext'` | 32 | 18 | 14 | 1 | 8 | 10 | 4 | 14 |

## Candidate Audit Summary

| Metric | Count |
|---|---:|
| `aesop_safe_fact_available` | 8 |
| `aesop_unsafe_fact_available` | 10 |
| `available` | 18 |
| `learned_candidate` | 32 |
| `proof_core` | 2 |
| `selected` | 32 |
| `simp_safe_available` | 4 |
| `simp_unsafe_available` | 14 |
| `target_or_alias` | 1 |
| `unavailable` | 14 |

### By Category

| Category | Count |
|---|---:|
| `definition_like` | 15 |
| `theorem_like` | 8 |
| `structure` | 5 |
| `simp_attr` | 3 |
| `class` | 1 |

### By Decl Kind

| Decl kind | Count |
|---|---:|
| `def` | 9 |
| `abbrev` | 7 |
| `theorem` | 7 |
| `structure` | 5 |
| `lemma` | 3 |
| `class` | 1 |

## Readout

- No non-empty-premise proof was found; inspect action failures before scaling.

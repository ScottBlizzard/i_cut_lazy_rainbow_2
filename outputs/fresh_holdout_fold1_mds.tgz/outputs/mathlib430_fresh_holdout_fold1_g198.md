# Mathlib 4.30 Replayable-Subset Proof-Action Matrix

- Verdict: `no_nonempty_positive`
- Replay filter: `/workspace/thymic_project/paper/iclr_2/outputs/mathlib430_pretheorem_original_tactic_probe_fold1_500.json`
- Pool mode: `legacy`
- Candidate source: `retrieved_only`
- Replayable goals evaluated: 1
- Attempts: 10
- Verified attempts: 0
- Non-empty-premise verified attempts: 0
- Goals with any proof: 0
- Goals with non-empty-premise proof: 0
- Action-dependent goals: 0

## Status Counts

| Status | Count |
|---|---:|
| `lean_error` | 9 |
| `search_fail` | 1 |

## By Action

| Action | Verified | Non-empty verified | Attempts |
|---|---:|---:|---:|
| `aesop_core` | 0 | 0 | 1 |
| `aesop_core_plus_learned` | 0 | 0 | 1 |
| `aesop_core_plus_learned16` | 0 | 0 | 1 |
| `aesop_core_plus_learned32` | 0 | 0 | 1 |
| `aesop_core_plus_learned_swapped` | 0 | 0 | 1 |
| `aesop_learned16` | 0 | 0 | 1 |
| `aesop_learned32` | 0 | 0 | 1 |
| `aesop_learned8` | 0 | 0 | 1 |
| `hammerCore_core_plus_learned` | 0 | 0 | 1 |
| `hammer_empty` | 0 | 0 | 1 |

## By Goal

| Goal | Verified | Non-empty verified | Empty verified | Best |
|---|---:|---:|---:|---|
| `mathlib4::SetLike.IsAtomic.IsCoatomic.BooleanAlgebra.CompleteBooleanAlgebra.IsAtomistic.IsCoatomistic.CompleteAtomicBooleanAlgebra.IsSimpleOrder.IsSimpleOrder.Set.OrderEmbedding.GaloisInsertion.GaloisCoinsertion.OrderIso.isAtomic_iff` | 0 | 0 | 0 | none |

## Availability

| Goal | Checked | Available | Failed | Target/alias | Aesop-safe available | Aesop-unsafe available | Simp-safe available | Simp-unsafe available |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| `mathlib4::SetLike.IsAtomic.IsCoatomic.BooleanAlgebra.CompleteBooleanAlgebra.IsAtomistic.IsCoatomistic.CompleteAtomicBooleanAlgebra.IsSimpleOrder.IsSimpleOrder.Set.OrderEmbedding.GaloisInsertion.GaloisCoinsertion.OrderIso.isAtomic_iff` | 32 | 1 | 31 | 0 | 0 | 1 | 0 | 1 |

## Candidate Audit Summary

| Metric | Count |
|---|---:|
| `aesop_safe_fact_available` | 0 |
| `aesop_unsafe_fact_available` | 1 |
| `available` | 1 |
| `learned_candidate` | 32 |
| `proof_core` | 1 |
| `selected` | 32 |
| `simp_safe_available` | 0 |
| `simp_unsafe_available` | 1 |
| `target_or_alias` | 0 |
| `unavailable` | 31 |

### By Category

| Category | Count |
|---|---:|
| `theorem_like` | 13 |
| `simp_attr` | 11 |
| `definition_like` | 4 |
| `class` | 2 |
| `structure` | 2 |

### By Decl Kind

| Decl kind | Count |
|---|---:|
| `theorem` | 17 |
| `lemma` | 6 |
| `def` | 4 |
| `class` | 2 |
| `structure` | 2 |
| `abbrev` | 1 |

## Readout

- No non-empty-premise proof was found; inspect action failures before scaling.
